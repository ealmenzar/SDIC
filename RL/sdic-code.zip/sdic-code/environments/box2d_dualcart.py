import numpy as np
import matplotlib.pyplot as plt
from gym.spaces import Discrete, Box

import os, sys
sys.path.append(os.path.join(os.path.dirname(__file__), "box2d_RobotSimLib"))

import Box2DWorld
import VectorFigUtils
from Box2DWorld import TIME_STEP, vel_iters, pos_iters
from ExpRobotSetup import ExpSetupDualCartPole




class Control():
    """Control class: feedback cascade pid + Cerebellum based adaptive filter."""

    def __init__(self, k_p_a=10, k_i_a=0.0, k_d_a=0.0, k_p_v=.04, k_i_v=0.0, k_d_v=0.0, bias=0.0):
        """Init function: angle pid params, velocity pid params, cerebellum params."""
        self.bias = bias
        self.i_angle = 0       # integral acc variable for angle
        self.i_vel = 0         # integral acc variable for velocity
        self.err_angle_t = 0   # precedent timestep angle error for derivative term
        self.err_vel_t = 0     # precedent timestep velocity error for derivative term

        self.k_p_a, self.k_i_a, self.k_d_a = k_p_a, k_i_a, k_d_a   # angle pid constants
        self.k_p_v, self.k_i_v, self.k_d_v = k_p_v, k_i_v, k_d_v   # velocity pid constants

        self.reset_fbk()


    def fbk_ctrl_angle(self, angle):
        """Feedback control function: not in use for the moment: only cascade is used."""
        self.i_angle += angle
        return -(angle * self.k_p_a + self.i_angle * self.k_i_a)

    def fbk_ctrl_vel(self, vel, tgt_vel):
        """Feedback control function: not in use for the moment: only cascade is used."""
        err_vel = tgt_vel - vel
        self.i_vel += err_vel
        tgt_angle = self.k_p_v * err_vel + self.k_i_v * self.i_vel + self.k_d_v * (err_vel - self.err_vel_t)
        #tgt_angle = -tgt_angle + self.bias
        self.err_vel_t = err_vel
        return tgt_angle

    def fbk_cascade_ctrl(self, angle, vel, tgt_vel):
        """Feedback cascade control function: velocity target generates target angle."""
        err_vel = tgt_vel - vel
        self.i_vel += err_vel
        tgt_angle = self.k_p_v * err_vel + self.k_i_v * self.i_vel + self.k_d_v * (err_vel - self.err_vel_t)
        tgt_angle = -tgt_angle + self.bias
        self.err_vel_t = err_vel

        err_angle = tgt_angle - angle
        self.err_angle = err_angle

        self.i_angle += err_angle
        fbk_out = self.k_p_a * err_angle + self.k_i_a * self.i_angle + self.k_d_a * (err_angle - self.err_angle_t)

        self.err_angle_t = err_angle
        return fbk_out

    def reset_fbk(self):
        """Reset integral values of cascade pid."""
        self.i_angle = 0
        self.i_vel = 0
        self.err_angle_t = 0
        self.err_vel_t = 0



class DualCartSimEnv(ExpSetupDualCartPole):

    def __init__(self, multi_agent_mode=1):
        super().__init__(debug=True, xshift=-2.1)
        self.observation_space = Box(low=-np.inf, high=np.inf, shape=(9,), dtype=np.float32)

        self.multi_agent_mode = multi_agent_mode
        # action space has only one continuous action if multi_agent_mode == 0
        self.action_space = Box(low=-10, high=10, shape=(1 + multi_agent_mode,), dtype=np.float32)
        
        self.start()

        self.goal = 1
        self.goal_timer_ini = 500
        self.goal_timer = self.goal_timer_ini
        self.goal_num = 0
        self.goal_targets = 100

        conf_av = {"k_p_a": 40, "k_p_v": 0.006, "k_i_a": 0, "k_i_v": 0, "k_d_a": 0, "k_d_v": 0}
        conf_a = {"k_p_a": 80, "k_p_v": 0, "k_i_a": 0, "k_i_v": 0, "k_d_a": 0, "k_d_v": 0}

        self.ctrls = [Control(**conf_av, bias=0.0), Control(**conf_a, bias=-0.03)]

        print("DualCartSimEnv created with episode steps",self.goal_timer_ini)

    def close(self):
        pass

    def render(self, param=None):
        if(param is None):
            fig, ax = VectorFigUtils.makeFigure(axes=[-5,5,-1.5,5.5])
            Box2DWorld.plotWorld(ax)
            plt.show()
        else:
            import pygame
            from PyGameUtils import draw_world, draw_salient, draw_circle_raw
            draw_world(param)
            draw_salient(param, self)
            obs = self.get_state()
            dist_other = 1.2
            tgt_x = -2 if(obs[2] == 0) else 2
            xmean = (obs[0][0] + obs[1][0]) / 2
            draw_circle_raw(param, xmean, 2, color=(200, 100, 30))
            draw_circle_raw(param, tgt_x, 2)
            draw_circle_raw(param, tgt_x-dist_other, 2, r=3)
            draw_circle_raw(param, tgt_x+dist_other, 2, r=3)


    def reset(self):
        self.start()
        self.update()
        self.goal_timer = self.goal_timer_ini
        self.goal = 1
        self.goal_num = 0
        return self.get_state()


    def get_state(self):
        pos = self.getPositions()
        angles = self.getAngles()
        vels = self.getVelocities()
        irs = self.getIRs()

        states = [None,None]
        for i in [0,1]:
            states[i] = [pos[i],angles[i],vels[i],irs[i]]

        return states + [self.goal] + [self.goal_timer]

    def fbk_step(self):
        obs = self.get_state()

        obs_0, obs_1 = obs[0], obs[1]
        ctrl_0, ctrl_1 = self.ctrls
        xoff = 4
        pos = np.array([obs_0[0], obs_1[0]]) + xoff  # we always maintain a positive position
        angles = np.array([obs_0[1], obs_1[1]])
        vel = np.array([obs_0[2], obs_1[2]])
        ir_s = np.array([obs_0[3], obs_1[3]])

        tgt_x = -2 if(obs[2] == 0) else 2          # obs[2] is the goal number and obs[3] the timer
        tgt_x += xoff

        max_vel = 12
        dist_other = 1.2
        error_pos_0 = tgt_x - dist_other - pos[0]
        error_pos_1 = tgt_x + dist_other - pos[1]

        tgt_vel_0 = np.clip(10*error_pos_0, -max_vel, max_vel)
        tgt_vel_1 = np.clip(10*error_pos_1, -max_vel, max_vel)

        fbk_0 = ctrl_0.fbk_cascade_ctrl(angles[0], vel[0], tgt_vel_0)
        fbk_1 = ctrl_1.fbk_cascade_ctrl(angles[1], vel[1], tgt_vel_1)

        return [fbk_0, fbk_1]

    def isclose(self, a, b, rel_tol=1e-02, abs_tol=0.0):
        return abs(a - b) <= max(rel_tol * max(abs(a), abs(b)), abs_tol)

    def step(self, action):

        r = 0.0
        if(self.multi_agent_mode == 1):
            r = np.array([0.0,0.0])

        action = np.array(action).astype(float)
        if(self.multi_agent_mode == 2):
            print("CONTROL")
            action += np.array(self.fbk_step())

        for i in [0,1]:
            self.setMotorSpeed(i, 10*action[i])  # proportional constant added to the action

        Box2DWorld.world.Step(TIME_STEP, vel_iters, pos_iters)
        self.update()

        self.goal_timer -= 1
        if(self.goal_timer == 0):
            self.goal_timer = self.goal_timer_ini
            self.goal = 1 - self.goal
            self.goal_num += 1

        positions = np.array(self.getPositions())
        mean_xpos = np.mean(positions)

        high = np.array(self.getPositionsY())
        angles = np.array(self.getAngles())

        angle_limit = 0.9
        high_limit = -0.26
        bad_angle = (angles < -angle_limit) | (angles > angle_limit)
        bad_height =  high > high_limit
        bads = np.any(bad_angle) or np.any(bad_height)
        if(bads or positions[1] > 4.1):
            r -= 100
            #if(bad_height[0] or bad_height[1]): r -= 100
            if(bad_angle[0]): r[0] -= 100
            if(bad_angle[1]): r[1] -= 100

        xtarget = 2 if self.goal == 1 else -2
        dist = abs(-xtarget - mean_xpos) if self.goal == 0 else abs(xtarget - mean_xpos)

        min_dist = 0.5
        for i in [0, 1]:
            # if (dist < min_dist):
            #      r[i] += 10 * (min_dist - dist)
            r[i] += 10 if self.isclose(mean_xpos, xtarget, 1e-01) else 0
            #r[i] += 0.1 * max(0.3 - abs(angles[i]), 0)

        done = bads or self.goal_num >= self.goal_targets

        return self.get_state(),r,done,{}


