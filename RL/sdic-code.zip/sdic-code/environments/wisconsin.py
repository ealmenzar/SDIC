import os
from copy import deepcopy
import pygame
import numpy as np
import random
import collections
import click

Black = (0,0,0)
White = (230,230,230)
Blue = (0,0,255)
Green = (0,255,0)
Red = (255,0,0)
Yellow = (255,255,0)


class Wisconsin(object):
    def __init__(self, gamelen = 50, rendering= True, rng=None):
        self.game_len = gamelen
        self.rgb = {"Black":(0,0,0), "White":(230,230,230), "Blue":(0,0,255), "Green":(0,255,0), "Red": (255,0,0), "Yellow": (255,255,0)}
        if rng == None:
            self.rng = np.random.RandomState(1234)
        else:
            self.rng = rng

        self.legal_actions = [0,1,2,3]
        self.action_meanings = ["1st Card", "2nd Card", "3rd Card", "4th Card"]
        self.num_action = len(self.legal_actions)

        self.mistakes = 0
        self.rep_mistakes = 0
        self.hit = True
        self.last_round_hit = True

        self.state_mode = "mini"

        self.open_cards = [(1,"Red","Circle"), (2, "Green","Triangle"), (3,"Blue", "Square"), (4,"Yellow","Plus")]

        self.scr_w = 105
        self.scr_h = 100

        self.rendering_scale = 10
        self.deck = []
        self.colors = ["Red", "Green", "Blue", "Yellow"]
        self.shapes = ["Circle", "Triangle", "Square", "Plus"]
        self.rules = ["Number", "Color", "Shape"]

        self.rule = self.rules[random.randint(0,2)]

        for n in range(1, 5):
            for c in self.colors:
                for s in self.shapes:
                    card = (n, c, s)
                    self.deck.append(card)

        self._rendering = rendering

        if rendering:
            self._init_pygame()

        self.game_over = False
        self.reset()

    def close(self):
        if self.rendering:
            pygame.quit()

    def _init_pygame(self):
        pygame.init()
        size = [self.rendering_scale * self.scr_w, self.rendering_scale * self.scr_h]
        self.screen = pygame.display.set_mode(size)
        pygame.display.set_caption("Wisconsin Card Test")

    @property
    def rendering(self):
        return self._rendering

    @rendering.setter
    def rendering(self, flag):
        if flag is True:
            if self._rendering is False:
                self._init_pygame()
                self._rendering = True
        else:
            self.close()
            self._rendering = False

    def get_state(self):

        if self.state_mode == 'hot':
            return self.get_state_hot()

        elif self.state_mode == 'mini':
            return self.get_state_mini()

        elif self.state_mode == "maxi":
            return self.get_state_maxi()

    def get_state_hot(self):
        # One hot vector
        pass

    def get_state_maxi(self):
        # 4 open cards + self card
        pass

    def get_state_mini(self):
        number_layer=[0,0,0,0]
        color_layer=[0,0,0,0]
        shape_layer=[0,0,0,0]

        number_layer[self.chosen[0]-1] = 1
        color_layer[self.colors.index(self.chosen[1])] = 1
        shape_layer[self.shapes.index(self.chosen[2])] = 1

        layers = []
        layers.append(number_layer)
        layers.append(color_layer)
        layers.append(shape_layer)

        state = np.stack(layers)
        return state

    def reset(self):

        random.shuffle(self.deck)
        self.game_over = False
        self.step_n = 0
        self.chosen = self.deck[self.step_n]

        if self.state_mode == 'one-hot':
            # Open cards + chosen card
            self.state_shape = [3, 4, 5]
        elif self.state_mode == 'mini':
            # Chosen card
            self.state_shape = [3,4]

        self.get_state()

    def check(self, action):
        assert action in self.legal_actions, 'Illegal action.'


        if self.rule == "Number":
            if self.chosen[0] == self.open_cards[action][0]:
                self.hit = True
                self.counter = 0
            else:
                self.hit = False

        elif self.rule == "Color":
            if self.chosen[1] == self.open_cards[action][1]:
                self.hit = True
                self.counter = 0
            else:
                self.hit = False

        elif self.rule == "Shape":
            if self.chosen[2] == self.open_cards[action][2]:
                self.hit = True
                self.counter = 0
            else:
                self.hit= False

        if self.hit == False:
            self.mistakes +=1
            if self.last_round_hit == False:
                self.rep_mistakes += 1 # Other implementations possible (such as comparing last played rule to current played rule!)
        else:
            self.last_round_hit = True

        if self.step_n % 10 == 0:
            self.change_rule()


    def change_rule(self):
        self.rule = self.rules[random.randint(0,2)]

    def step(self, action):

        if self.game_over:
            raise ValueError('Environment has already been terminated.')

        if self.step_n >= self.game_len - 1:
            self.game_over = True

            return self.get_state(), 0., self.game_over, None

        self.check(action)

        if self.hit == True:
            reward = 1
        else:
            reward = 0

        self.step_n += 1

        return self.get_state(), reward, self.game_over, None

    def render(self):

        if not self.rendering:
            return

        pygame.event.pump()
        self.screen.fill(Black)
        card_size = [20, 20]
        card_x = [5, 30, 55, 80]

        for i in range(4):
            card_bg = pygame.Rect(card_x[i]*self.rendering_scale, 20*self.rendering_scale, card_size[0]*self.rendering_scale, card_size[1]*self.rendering_scale)
            pygame.draw.rect(self.screen, White, card_bg)

            if i == 0:
                c_center = (15 * self.rendering_scale, 30*self.rendering_scale)
                c_rad = int(3*self.rendering_scale)
                pygame.draw.circle(self.screen, Red, c_center, c_rad)

            if i == 1:
                points_1 = [(31.5*self.rendering_scale, 32*self.rendering_scale), (38.5*self.rendering_scale, 32*self.rendering_scale), (35*self.rendering_scale, 26*self.rendering_scale)]
                points_2 = [(41.5*self.rendering_scale, 32*self.rendering_scale), (48.5*self.rendering_scale, 32* self.rendering_scale), (45*self.rendering_scale, 26*self.rendering_scale)]
                pygame.draw.polygon(self.screen, Green, points_1, 0)
                pygame.draw.polygon(self.screen, Green, points_2, 0)

            if i == 2:
                s1 = pygame.Rect(58*self.rendering_scale, 31*self.rendering_scale, 6*self.rendering_scale, 6*self.rendering_scale)
                s2 = pygame.Rect(66*self.rendering_scale, 31*self.rendering_scale, 6*self.rendering_scale, 6*self.rendering_scale)
                s3 = pygame.Rect(62*self.rendering_scale, 23*self.rendering_scale, 6*self.rendering_scale, 6*self.rendering_scale)
                pygame.draw.rect(self.screen, Blue, s1)
                pygame.draw.rect(self.screen, Blue, s2)
                pygame.draw.rect(self.screen, Blue, s3)

            if i ==3:
                a_x = pygame.Rect(82*self.rendering_scale,24*self.rendering_scale,6*self.rendering_scale,2*self.rendering_scale)
                a_y = pygame.Rect(84*self.rendering_scale,22*self.rendering_scale,2*self.rendering_scale,6*self.rendering_scale)
                pygame.draw.rect(self.screen, Yellow, a_x)
                pygame.draw.rect(self.screen, Yellow, a_y)
                b_x = pygame.Rect(92*self.rendering_scale,34*self.rendering_scale,6*self.rendering_scale,2*self.rendering_scale)
                b_y = pygame.Rect(94*self.rendering_scale,32*self.rendering_scale,2*self.rendering_scale,6*self.rendering_scale)
                pygame.draw.rect(self.screen, Yellow, b_x)
                pygame.draw.rect(self.screen, Yellow, b_y)
                c_x = pygame.Rect(92*self.rendering_scale,24*self.rendering_scale,6*self.rendering_scale,2*self.rendering_scale)
                c_y = pygame.Rect(94*self.rendering_scale,22*self.rendering_scale,2*self.rendering_scale,6*self.rendering_scale)
                pygame.draw.rect(self.screen, Yellow, c_x)
                pygame.draw.rect(self.screen, Yellow, c_y)
                d_x = pygame.Rect(82*self.rendering_scale,34*self.rendering_scale,6*self.rendering_scale,2*self.rendering_scale)
                d_y = pygame.Rect(84*self.rendering_scale,32*self.rendering_scale,2*self.rendering_scale,6*self.rendering_scale)
                pygame.draw.rect(self.screen, Yellow, d_x)
                pygame.draw.rect(self.screen, Yellow, d_y)


        chosen_card = pygame.Rect(40*self.rendering_scale , 60*self.rendering_scale, card_size[0]*self.rendering_scale, card_size[1]*self.rendering_scale)
        pygame.draw.rect(self.screen, White, chosen_card)

        if self.chosen[2] == "Circle":
            if self.chosen[0] == 1:
                pygame.draw.circle(self.screen, self.rgb[self.chosen[1]], (50*self.rendering_scale,70*self.rendering_scale), 3*self.rendering_scale)
            elif self.chosen[0] == 2:
                pygame.draw.circle(self.screen, self.rgb[self.chosen[1]], (45*self.rendering_scale,70*self.rendering_scale), 3*self.rendering_scale)
                pygame.draw.circle(self.screen, self.rgb[self.chosen[1]], (55*self.rendering_scale,70*self.rendering_scale), 3*self.rendering_scale)
            elif self.chosen[0] == 3:
                pygame.draw.circle(self.screen, self.rgb[self.chosen[1]], (50 * self.rendering_scale, 65 * self.rendering_scale), 3 * self.rendering_scale)
                pygame.draw.circle(self.screen, self.rgb[self.chosen[1]], (55 * self.rendering_scale, 75 * self.rendering_scale), 3 * self.rendering_scale)
                pygame.draw.circle(self.screen, self.rgb[self.chosen[1]], (45 * self.rendering_scale, 75 * self.rendering_scale), 3 * self.rendering_scale)
            elif self.chosen[0] == 4:
                pygame.draw.circle(self.screen, self.rgb[self.chosen[1]], (45 * self.rendering_scale, 65 * self.rendering_scale), 3 * self.rendering_scale)
                pygame.draw.circle(self.screen, self.rgb[self.chosen[1]], (45 * self.rendering_scale, 75 * self.rendering_scale), 3 * self.rendering_scale)
                pygame.draw.circle(self.screen, self.rgb[self.chosen[1]], (55 * self.rendering_scale, 65 * self.rendering_scale), 3 * self.rendering_scale)
                pygame.draw.circle(self.screen, self.rgb[self.chosen[1]], (55 * self.rendering_scale, 75 * self.rendering_scale), 3 * self.rendering_scale)

        elif self.chosen[2] == "Square":

            if self.chosen[0] == 1:
                sq0 = pygame.Rect(47*self.rendering_scale, 67*self.rendering_scale, 6*self.rendering_scale,6*self.rendering_scale)
                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], sq0)

            if self.chosen[0] == 2:
                sq1 = pygame.Rect(42 * self.rendering_scale, 67 * self.rendering_scale, 6 * self.rendering_scale,6 * self.rendering_scale)
                sq2 = pygame.Rect(52 * self.rendering_scale, 67 * self.rendering_scale, 6 * self.rendering_scale,6 * self.rendering_scale)
                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], sq1)
                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], sq2)

            if self.chosen[0] == 3:
                sq3 = pygame.Rect(47 * self.rendering_scale, 62 * self.rendering_scale, 6 * self.rendering_scale,
                                  6 * self.rendering_scale)
                sq4 = pygame.Rect(42 * self.rendering_scale, 72 * self.rendering_scale, 6 * self.rendering_scale,
                                  6 * self.rendering_scale)
                sq5 = pygame.Rect(52 * self.rendering_scale, 72 * self.rendering_scale, 6 * self.rendering_scale,
                                  6 * self.rendering_scale)
                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], sq3)
                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], sq4)
                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], sq5)

            if self.chosen[0] == 4:
                sq6 = pygame.Rect(42 * self.rendering_scale, 62 * self.rendering_scale, 6 * self.rendering_scale,
                                  6 * self.rendering_scale)
                sq7 = pygame.Rect(52 * self.rendering_scale, 62 * self.rendering_scale, 6 * self.rendering_scale,
                                  6 * self.rendering_scale)
                sq8 = pygame.Rect(42 * self.rendering_scale, 72 * self.rendering_scale, 6 * self.rendering_scale,
                                  6 * self.rendering_scale)
                sq9 = pygame.Rect(52 * self.rendering_scale, 72 * self.rendering_scale, 6 * self.rendering_scale,
                                  6 * self.rendering_scale)
                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], sq6)
                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], sq7)

                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], sq8)
                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], sq9)
        elif self.chosen[2] == "Triangle":

            if self.chosen[0] == 1:
                corners0 = [(53.5 * self.rendering_scale, 72 * self.rendering_scale),
                            (46.5 * self.rendering_scale, 72 * self.rendering_scale),
                            (50 * self.rendering_scale, 66 * self.rendering_scale)]
                pygame.draw.polygon(self.screen, self.rgb[self.chosen[1]], corners0, 0)

            if self.chosen[0] == 2:

                corners1 = [(41.5 * self.rendering_scale, 72 * self.rendering_scale),
                            (48.5 * self.rendering_scale, 72 * self.rendering_scale),
                            (45 * self.rendering_scale, 66 * self.rendering_scale)]

                corners2 = [(51.5 * self.rendering_scale, 72 * self.rendering_scale),
                            (58.5 * self.rendering_scale, 72 * self.rendering_scale),
                            (55 * self.rendering_scale, 66 * self.rendering_scale)]

                pygame.draw.polygon(self.screen, self.rgb[self.chosen[1]], corners1, 0)
                pygame.draw.polygon(self.screen, self.rgb[self.chosen[1]], corners2, 0)

            if self.chosen[0] == 3:

                corners3 = [(41.5 * self.rendering_scale, 78 * self.rendering_scale),
                            (48.5 * self.rendering_scale, 78 * self.rendering_scale),
                            (45 * self.rendering_scale, 72 * self.rendering_scale)]

                corners4 = [(51.5 * self.rendering_scale, 78 * self.rendering_scale),
                            (58.5 * self.rendering_scale, 78 * self.rendering_scale),
                            (55 * self.rendering_scale, 72 * self.rendering_scale)]

                corners5 = [(53.5 * self.rendering_scale, 68 * self.rendering_scale),
                            (46.5 * self.rendering_scale, 68 * self.rendering_scale),
                            (50 * self.rendering_scale, 62 * self.rendering_scale)]

                pygame.draw.polygon(self.screen, self.rgb[self.chosen[1]], corners3, 0)
                pygame.draw.polygon(self.screen, self.rgb[self.chosen[1]], corners4, 0)
                pygame.draw.polygon(self.screen, self.rgb[self.chosen[1]], corners5, 0)

            if self.chosen[0] == 4:

                corners6 = [(41.5 * self.rendering_scale, 78 * self.rendering_scale),
                            (48.5 * self.rendering_scale, 78 * self.rendering_scale),
                            (45 * self.rendering_scale, 72 * self.rendering_scale)]

                corners7 = [(51.5 * self.rendering_scale, 78 * self.rendering_scale),
                            (58.5 * self.rendering_scale, 78 * self.rendering_scale),
                            (55 * self.rendering_scale, 72 * self.rendering_scale)]

                corners8 = [(41.5 * self.rendering_scale, 68 * self.rendering_scale),
                            (48.5 * self.rendering_scale, 68 * self.rendering_scale),
                            (45 * self.rendering_scale, 62 * self.rendering_scale)]

                corners9 = [(51.5 * self.rendering_scale, 68 * self.rendering_scale),
                            (58.5 * self.rendering_scale, 68 * self.rendering_scale),
                            (55 * self.rendering_scale, 62 * self.rendering_scale)]

                pygame.draw.polygon(self.screen, self.rgb[self.chosen[1]], corners6, 0)
                pygame.draw.polygon(self.screen, self.rgb[self.chosen[1]], corners7, 0)
                pygame.draw.polygon(self.screen, self.rgb[self.chosen[1]], corners8, 0)
                pygame.draw.polygon(self.screen, self.rgb[self.chosen[1]], corners9, 0)


        elif self.chosen[2] == "Plus":

            if self.chosen[0] == 1:

                a_x = pygame.Rect(47 * self.rendering_scale, 69 * self.rendering_scale, 6 * self.rendering_scale,
                                  2 * self.rendering_scale)
                a_y = pygame.Rect(49 * self.rendering_scale, 67 * self.rendering_scale, 2 * self.rendering_scale,
                                  6 * self.rendering_scale)

                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], a_x)
                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], a_y)

            if self.chosen[0] == 2:
                a_x = pygame.Rect(42 * self.rendering_scale, 69 * self.rendering_scale, 6 * self.rendering_scale,
                                  2 * self.rendering_scale)
                a_y = pygame.Rect(44 * self.rendering_scale, 67 * self.rendering_scale, 2 * self.rendering_scale,
                                  6 * self.rendering_scale)
                b_x = pygame.Rect(52 * self.rendering_scale, 69 * self.rendering_scale, 6 * self.rendering_scale,
                                  2 * self.rendering_scale)
                b_y = pygame.Rect(54 * self.rendering_scale, 67 * self.rendering_scale, 2 * self.rendering_scale,
                                  6 * self.rendering_scale)

                pygame.draw.rect(self.screen,self.rgb[self.chosen[1]], b_x)
                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], b_y)
                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], a_x)
                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], a_y)

            if self.chosen[0] == 3:

                a_x = pygame.Rect(42 * self.rendering_scale, 69 * self.rendering_scale, 6 * self.rendering_scale,
                                  2 * self.rendering_scale)
                a_y = pygame.Rect(44 * self.rendering_scale, 67 * self.rendering_scale, 2 * self.rendering_scale,
                                  6 * self.rendering_scale)
                b_x = pygame.Rect(52 * self.rendering_scale, 69 * self.rendering_scale, 6 * self.rendering_scale,
                                  2 * self.rendering_scale)
                b_y = pygame.Rect(54 * self.rendering_scale, 67 * self.rendering_scale, 2 * self.rendering_scale,
                                  6 * self.rendering_scale)
                c_x = pygame.Rect(47 * self.rendering_scale, 69 * self.rendering_scale, 6 * self.rendering_scale,
                                  2 * self.rendering_scale)
                c_y = pygame.Rect(49 * self.rendering_scale, 67 * self.rendering_scale, 2 * self.rendering_scale,
                                  6 * self.rendering_scale)

                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], a_x)
                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], a_y)
                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], b_x)
                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], b_y)
                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], c_x)
                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], c_y)

            if self.chosen[0] == 4:

                a_x = pygame.Rect(42*self.rendering_scale,64*self.rendering_scale,6*self.rendering_scale,2*self.rendering_scale)
                a_y = pygame.Rect(44*self.rendering_scale,62*self.rendering_scale,2*self.rendering_scale,6*self.rendering_scale)
                b_x = pygame.Rect(52*self.rendering_scale,74*self.rendering_scale,6*self.rendering_scale,2*self.rendering_scale)
                b_y = pygame.Rect(54*self.rendering_scale,72*self.rendering_scale,2*self.rendering_scale,6*self.rendering_scale)
                c_x = pygame.Rect(52*self.rendering_scale,64*self.rendering_scale,6*self.rendering_scale,2*self.rendering_scale)
                c_y = pygame.Rect(54*self.rendering_scale,62*self.rendering_scale,2*self.rendering_scale,6*self.rendering_scale)
                d_x = pygame.Rect(42*self.rendering_scale,74*self.rendering_scale,6*self.rendering_scale,2*self.rendering_scale)
                d_y = pygame.Rect(44*self.rendering_scale,72*self.rendering_scale,2*self.rendering_scale,6*self.rendering_scale)

                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], c_x)
                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], c_y)
                pygame.draw.rect(self.screen,self.rgb[self.chosen[1]], b_x)
                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], b_y)
                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], a_x)
                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], a_y)
                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], d_x)
                pygame.draw.rect(self.screen, self.rgb[self.chosen[1]], d_y)


        pygame.display.flip()