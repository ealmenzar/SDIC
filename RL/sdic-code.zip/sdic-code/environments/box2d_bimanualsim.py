import numpy as np
import sys
import math

import matplotlib
import matplotlib.pyplot as plt

from gym.spaces import Discrete, Box

import os, sys
sys.path.append(os.path.join(os.path.dirname(__file__), "box2d_RobotSimLib"))

import Box2DWorld
import VectorFigUtils
from Box2DWorld import TIME_STEP, vel_iters, pos_iters
from PyGameUtils import draw_world, draw_salient
from ExpRobotSetup import ExpSetupNao


class BimanualSimEnv(ExpSetupNao):

    def __init__(self):
        super().__init__(pos_nao=(0,0),pos_obj=(0,1.5),obj_type="box",salientMode='minimum')
        self.observation_space = Box(low=-np.inf, high=np.inf, shape=(8,), dtype=np.float32)
        self.action_space = Discrete(6)
        self.start()
        self.update()

    def render(self, param=None):
        if(param is None):
            fig, ax = VectorFigUtils.makeFigure(axes=[-1.8,1.8,-.5,2.5])            
            Box2DWorld.plotWorld(ax)
            plt.show()
        else:
            draw_world(param)
            draw_salient(param, self)        

    def reset(self):
        self.start()
        self.update()

    def get_state(self):
    	return self.get_salient()

    def step(self, action):
        self.deltaMotor(dm=action)      
        for i in [0,1]:
        	Box2DWorld.world.Step(TIME_STEP, vel_iters, pos_iters)
        	Box2DWorld.world.ClearForces()
        self.update()
        return [],0,False,{}


