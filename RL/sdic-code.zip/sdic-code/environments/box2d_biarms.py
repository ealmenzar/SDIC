import numpy as np
import sys
import math

import matplotlib
import matplotlib.pyplot as plt

from gym.spaces import Discrete, Box

import os, sys
sys.path.append(os.path.join(os.path.dirname(__file__), "box2d_RobotSimLib"))

import Box2DWorld
import VectorFigUtils
from Box2DWorld import TIME_STEP, vel_iters, pos_iters

import PyGameUtils 
from PyGameUtils import draw_world, draw_salient, draw_contacts
from ExpRobotSetup import ExpSetupNao


class TwoArmsEnv(ExpSetupNao):

    def __init__(self):
        super().__init__(debug = True, name ="TwoOppositeArms")
        PyGameUtils.PPM = 100
        self.observation_space = Box(low=-np.inf, high=np.inf, shape=(8,), dtype=np.float32)
        self.action_space = Discrete(6)
        self.start()

        self.goal = 1
        self.goal_timer_ini = 1000
        self.goal_timer = self.goal_timer_ini
        self.goal_num = 0
        self.goal_targets = 100


    def render(self, param=None):
        if(param is None):
            fig, ax = VectorFigUtils.makeFigure(axes=[-2,2,-.5,3.5])
            plt.yticks(np.arange(-.5,4, 0.5))
            plt.xticks(np.arange(-2,2.5,0.5))
            Box2DWorld.plotWorld(ax)
            Box2DWorld.plotVectors(ax, self.getSalient(), haptic=self.haptic, dirs=self.getSalientVel(), label='s')
            #plt.show()
            return fig
        else:
            draw_world(param)
            draw_contacts(param,self)
            draw_salient(param, self)

    def reset(self):
        self.start()
        self.update()
        Box2DWorld.world.Step(TIME_STEP, vel_iters, pos_iters)
        
        self.goal_timer = self.goal_timer_ini
        self.goal = 1
        self.goal_num = 0
        return self.get_state()

    def get_state(self):
        """
        self.salient is a list of 7 items, first 3 corresponding to the lower arm joint positions,
        second 3 to the upper arm joint positions and the last one corresponding to the ball position.

        """
        return self.salient + self.haptic + [self.goal] + [self.goal_timer]

    def step(self, action):
        r = np.array([0.0,0.0])
        self.deltaMotor(dm=action)
        Box2DWorld.world.Step(TIME_STEP, vel_iters, pos_iters)
        self.update()

        self.goal_timer -= 1
        if(self.goal_timer == 0):
            self.goal_timer = self.goal_timer_ini
            self.goal = 1 - self.goal
            self.goal_num += 1

        xtarget = 0.82
        xobj = self.salient[-1][0]
        dist = abs(-xtarget - xobj) if self.goal == 0 else abs(xtarget - xobj)

        min_dist = 0.05
        if(dist < min_dist):
            val = 10.0*(min_dist - dist)
            r += val

        done = self.goal_num >= self.goal_targets

        return self.get_state(), r, done, {}


