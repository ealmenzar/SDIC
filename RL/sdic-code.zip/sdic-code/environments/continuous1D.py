import numpy as np
import sys
import math
import random

class Continuous1D():
    """ Simple Continuous Environment
    """

    def __init__(self):
        """ The environment 
        """
        self.lim = 2
        #self.target_x = random.uniform(-self.lim + 0.1, self.lim - 0.1)
        self.target_x = 0.5
        self.reset()
        print("Simple Continuous Environment created with x target ", self.target_x)

    def info(self):
        return [self.lim, self.target_x]

    def reset(self):
        self.isteps = 0
        self.x = random.uniform(-self.lim, self.lim)
        while abs(self.target_x - self.x) < 0.1:
            self.x += 0.01
        self.x = 0

        return [self.x]

    def step(self, action):
        if type(action) in [list, np.ndarray]:
            action = action[0]

        self.isteps += 1
        self.x = np.clip(self.x + action, -self.lim, self.lim)
        r = -abs(self.target_x - self.x)
        done = abs(r) < 0.1 or self.isteps > 9
        return [self.x], r, done, []

    def render(self):
        print("State: ", self.x, "Objective:", self.target_x)

    def close(self):
        pass
