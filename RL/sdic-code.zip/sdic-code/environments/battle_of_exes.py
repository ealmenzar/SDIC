import numpy as np
import sys
import random
import math

from copy import deepcopy

import matplotlib
from matplotlib import pyplot as plt



font = {'family': 'Bitstream Vera Sans', 'size': 20}


def dist(p,q):
    return math.hypot(q[0] - p[0], q[1] - p[1])


def vrand():
    v = np.random.rand(2)-np.array([0.5,0.5])
    return v / np.linalg.norm(v)

def vnorm(u):
    return np.linalg.norm(u)

def vangle(u,v):
    unorm = np.linalg.norm(u)
    vnorm = np.linalg.norm(v)
    if(unorm == 0 or vnorm == 0):
        return 0
    c = np.dot(u, v) / unorm / vnorm
    angle = np.arccos(np.clip(c, -1, 1))
    return angle

def vangleSign(u,v):
    return -np.arctan2(v[1],v[0]) + np.arctan2(u[1],u[0])

def vrotate(v, angle, anchor=[0,0], mag=1):
    """Rotate a vector `v` by the given angle, relative to the anchor point."""
    x, y = v
    x = x - anchor[0]
    y = y - anchor[1]
    cos_theta = math.cos(angle)
    sin_theta = math.sin(angle)
    nx = x*cos_theta - y*sin_theta
    ny = x*sin_theta + y*cos_theta
    nx = nx + anchor[0]
    ny = ny + anchor[1]
    return [mag*nx, mag*ny]

def computePointsAngle(pos,vdir,dx = 1):
    vdir90 = vrotate(vdir, np.pi/2)
    p1 = [pos[0]+dx*vdir90[0],pos[1]+dx*vdir90[1]]
    p2 = [pos[0]-dx*vdir90[0],pos[1]-dx*vdir90[1]]
    p3 = [pos[0]+3*dx*vdir[0],pos[1]+3*dx*vdir[1]]
    return p1,p2,p3


def drawCircle(ax,position,r = 0.3, alpha = 0.4, color = 'b', fill=True, linestyle='solid'):
    lw = 1
    if(linestyle=='dashed'): lw = 3
    c = plt.Circle(position, radius=r, alpha=alpha, fill=fill, facecolor=color, edgecolor=color,ls=linestyle,linewidth=lw)
    ax.add_patch( c )
    return c

def drawBox(ax, vertices, alpha = 0.5, color = 'b', fill=True, linestyle='solid'):
    lw = 1
    if(linestyle=='dashed'): lw = 3
    poly = plt.Polygon(vertices, alpha=alpha, fill=fill, facecolor=color, edgecolor=color, ls=linestyle,linewidth=lw)
    ax.add_patch( poly )

def decorate(xlabel = None, ylabel = None, title = None, xticks = None, mainfont=20, legendfont=12, bLegend = False):
    global font
    font['size']=mainfont
    plt.rc('font', **font)
    plt.rc('legend',**{'fontsize':legendfont})
    if(xlabel != None): plt.xlabel(xlabel)
    if(ylabel != None): plt.ylabel(ylabel)
    if(title != None): plt.title(title)
    if(bLegend): plt.legend()



class Space(object):
    def __init__(self, mins, maxs):
        self.mins, self.maxs = np.array(mins), np.array(maxs)

class ActionSpace(Space):
    def __init__(self, mins, maxs):
        self.n = maxs[0]-mins[0]+1

class ObservationSpace(Space):

    def sample(self):
        mins = self.mins
        maxs = self.maxs
        self.low, self.high = mins, maxs
        l = len(mins-1)
        inputs = [(r*(maxs[i]-mins[i])+mins[i]) for i,r in enumerate(np.random.rand(l))]
        return inputs
    
class BattleOfExesEnv():    
    
    def __init__(self, reward_dist=1, secondary_radius=0.9, high_reward = 2, low_reward = 1):
        self.reward_dist = reward_dist  # ballistic corresponds to reward_dist = 1
        self.secondary_radius = secondary_radius
        self.init_session(high_reward=high_reward, low_reward=low_reward)
        
        v = 1.0
        self.v = v        

        self.x = 10
        self.targets = np.array([0, self.x/2.0, 0, -self.x/2.0])
        
        if(self.reward_dist > 1 and self.reward_dist <= 10):
            y = self.reward_dist
            self.targets = np.array([0, y, 0, -y])
        elif(self.reward_dist > 10):
            print("Reward Distance too big > 10")
            return
                
        self.maxd_AT = dist([-self.x,0],[0,self.targets[1]])
        self.maxd_AA = dist([-self.x,0],[self.x,0])
        
        if(reward_dist == 1):
            self.observation_space = ObservationSpace([0],[2])
        else:
            self.observation_space = ObservationSpace([0,0,0],[1,1,1])
                        
        self.action_space = ActionSpace([0,0],[1,1])
        
        self.init_trial()

    def init_session(self, high_reward = 2, low_reward = 1):    
        self.iframe = 0
        self.reward_high = high_reward
        self.reward_low = low_reward
                
        self.nepisodes = 0
        self.sum_reward = np.array([0.0,0.0])    # For each player (2 positions) on a SESSION basis
        self.sum_hpayoff = np.array([0,0])   # on a SESSION basis
        self.reward_prev = [0,0]             # on a SESSION basis updated when trial is done
        self.session_achanges = np.array([0,0])
        
        self.hist = {}
        self.hist["reward"] = []
        self.hist["hpayoff"] = []
        self.hist["achange"] = []
        self.hist["peeloff"] = []
        self.hist["tstep"] = []
        
    def init_trial(self):
        x,v = self.x, self.v
        if(self.reward_dist > 1 and self.reward_dist <= 10): x = 0
        
        self.positions = np.array([-x,0,x,0])
        self.dirs = np.array([v,0,-v,0])
        self.t = 0
        self.t_last_achange = [0,0]
        self.sum_achanges = np.array([0,0])             # on a TRIAL basis updated every time step
        self.action_prev = [-1,-1]                      # on a TRIAL basis updated every time step
        return  [self.get_obs(0), self.get_obs(1)]

    def reset(self):
        return self.init_trial()

    def sample(self):
        return self.observation_space.sample()
        
    def get_pos(self,i):  return self.positions[2*i:2*i+2]
    def get_target(self,i):  return self.targets[2*i:2*i+2]
    def get_dir(self,i):  return self.dirs[2*i:2*i+2]
    
    def distAT(self,i,j): return dist(self.get_pos(i),self.get_target(j)) 
    def distAA(self): return dist(self.get_pos(0),self.get_pos(1)) 
    
    def get_obs(self,i):            
        state_prev = 0
        if(self.reward_prev[0] > self.reward_low): 
            state_prev = 1 if(i==0) else 0.5
        elif(self.reward_prev[1] > self.reward_low): 
            state_prev =  0.5 if(i==0) else 1
            
         
        act_prev = self.action_prev 
        
        if(False):
            if(np.array_equal(act_prev,np.array([0,0]))): state_prev = 0
            if(np.array_equal(act_prev,np.array([0,1]))): state_prev = 1/3.0
            if(np.array_equal(act_prev,np.array([1,0]))): state_prev = 2/3.0
            if(np.array_equal(act_prev,np.array([1,1]))): state_prev = 3/3.0
            #state_prev = random.randint(0,2)/2.0

        #if(random.randint(0,10) == 0):  state_prev = random.randint(0,2)

        iother = 1-i
        
        vy_sign_o = 1 if self.get_dir(iother)[1] >= 0 else 0
        ach = np.min([self.sum_achanges[i] / 30.0, 1])
        ach_o = np.min([self.sum_achanges[iother] / 30.0, 1])
                
        xn = abs(self.get_pos(i)[0]) / float(self.x)
        yn = abs(self.get_pos(i)[1] + self.targets[1]) / float(2*self.targets[1])

        xn_o = abs(self.get_pos(iother)[0]) / float(self.x) 
        yn_o = abs(self.get_pos(iother)[1] + self.targets[1]) / float(2*self.targets[1])
        
        tstate = np.min([self.t/100.0,1])
                        
        if(self.reward_dist == 1):
            obs = np.array([2*state_prev])        
        else:
            obs = np.array([yn, yn_o, state_prev])        
        
        return obs

    def step(self,action):
        done, reward = False, [0, 0]
        
        if(self.reward_dist == 1):
            if(not np.equal.reduce(action)): 
                reward = [self.reward_low, self.reward_high]
                if(action[0] == 0):
                    reward = [self.reward_high, self.reward_low]
            done = True
            
        else:
            positions,dirs,targets = self.positions, self.dirs, self.targets
            next_state, new_dirs =  np.hstack((positions,dirs)), np.array([])

            for i,a in enumerate(action):
                new_dir = self.get_target(a) - self.get_pos(i)
                new_dir = self.v * new_dir / vnorm(new_dir)
                new_dirs = np.hstack((new_dirs,new_dir))

            self.positions = positions + new_dirs
            self.dirs = new_dirs
            next_state = np.hstack((positions,new_dirs))        

            if(self.reward_dist <= 10):
                th_dist = self.v
            else: 
                th_dist = 1.2*self.v
            
            for t in [0,1]:
                dists_t = [self.distAT(i,t) for i in [0,1]]
                if(np.min(dists_t) < th_dist):
                    if(self.distAA() >= self.secondary_radius):
                        reward = [self.reward_high, self.reward_low]
                        if((t==0 and dists_t[1] < th_dist) or (t==1 and dists_t[0] < th_dist)): 
                            reward = [self.reward_low, self.reward_high]
                    done = True
                    break

            self.t += 1
            if(self.t > 700): 
                done = True
                                

            achanges = np.array(action) != np.array(self.action_prev)
            if(achanges[0]): self.t_last_achange[0] = self.t
            if(achanges[1]): self.t_last_achange[1] = self.t
            self.sum_achanges += achanges
                
        if(done): 
            self.nepisodes += 1
            hpayoff = (np.array(reward) == self.reward_high)
            self.sum_hpayoff += hpayoff
            self.sum_reward += np.array(reward)            
            self.reward_prev = deepcopy(reward)
            self.session_achanges += self.sum_achanges

            self.hist["reward"] += [reward]
            self.hist["hpayoff"] += [hpayoff]        
            self.hist["achange"] += [self.sum_achanges]    
            self.hist["peeloff"] += [self.t_last_achange]
            self.hist["tstep"] += [self.t]
               
        self.action_prev = np.array(action)
        return [self.get_obs(0), self.get_obs(1)], np.array(reward), done, None

    
    def draw(self, bSave=False):
        x,v = self.x, self.v
        positions,dirs,targets = self.positions, self.dirs, self.targets

        if(self.reward_dist > 6):            
            fig, ax = VectorFigUtils.makeFigure(axes=[-x-4, x+4, -self.reward_dist-1, self.reward_dist+1])
        else:
            fig, ax = VectorFigUtils.makeFigure(axes=[-x-4, x+4, -x, x])
        
        l = computePointsAngle(positions[:2],dirs[:2],dx=0.4)
        VectorFigUtils.drawBox(ax,l, color='b')
        l = computePointsAngle(positions[2:4], dirs[2:4],dx=0.4)
        VectorFigUtils.drawBox(ax,l, color='r')
        
        VectorFigUtils.drawCircle(ax,targets[:2],r=self.secondary_radius, color='g',fill=False, linestyle='dashed')
        VectorFigUtils.drawCircle(ax,targets[2:4],r=self.secondary_radius, color='g',fill=False, linestyle='dashed')

        VectorFigUtils.drawCircle(ax,targets[:2],r=0.9,color='g')
        VectorFigUtils.drawCircle(ax,targets[2:4],r=0.4, color='g')
        
        VectorFigUtils.decorate("x","y",mainfont=14)
        ax.set_aspect('equal')
        
        if(not bSave):
            plt.show()
        else: 
            fig.savefig('imgs/setup%08d.png'%self.iframe, dpi=300, format='png')
            self.iframe += 1
                        
    def efficiency(self):
        if(self.nepisodes == 0): return 0
        return np.sum(self.sum_reward) / float(self.nepisodes*(self.reward_low+self.reward_high))

    def fairness(self):
        if(self.nepisodes == 0): return 0
        if(np.max(self.sum_hpayoff) == 0): return 1
        return np.min(self.sum_hpayoff) / float(np.max(self.sum_hpayoff)) 

    def efficiency_last(self,n=5):    
        if(self.nepisodes == 0): return 0
        last_rew = np.array(self.hist["reward"][-n:])        
        return np.sum(last_rew) / float(min(n,self.nepisodes)*(self.reward_low+self.reward_high))

    def fairness_last(self,n=5):
        if(self.nepisodes == 0): return 0
        last_sum_hpayoff = sum(np.array(self.hist["hpayoff"][-n:]))        
        if(np.max(last_sum_hpayoff) == 0): return 1
        return np.min(last_sum_hpayoff) / float(np.max(last_sum_hpayoff))

    def timesteps(self):    
        if(self.nepisodes == 0): return 0
        tsteps = np.array(self.hist["tstep"]) 
        return np.sum(tsteps) / float(self.nepisodes)

    def ties(self):    
        if(self.nepisodes == 0): return 0
        return self.nepisodes - np.count_nonzero(self.hist['hpayoff'])

    def hpayoff_last(self,i,n=3):
        try:
            score = np.count_nonzero(np.array(self.hist['hpayoff'])[-n:,i])
        except:
            score = 0 if self.hist['hpayoff'] == [] else np.count_nonzero(np.array(self.hist['hpayoff'])[:,i])
        return score

    
    def action_changes(self):
        return np.mean(self.session_achanges / float(self.nepisodes))

    def close(self):
        pass


class BattleOfExesMin():

    def __init__(self, conf):
        self.num_agents = 2
        self.dist = 2
        self.radius = 1
        self.high = 2
        self.low = 1
        self.state = [0]

        if (self.num_agents < 2 or self.dist < 1):
            print("BoE: minimum agents = 2, minimum distance = 1")
            return

        self.conf = conf
        if ("num_agents" in conf):  self.num_agents = conf["num_agents"]
        if ("dist" in conf):  self.dist = conf["dist"]
        if ("radius" in conf):  self.radius = conf["radius"]
        if ("high" in conf):  self.high = conf["high"]
        if ("low" in conf):  self.low = conf["low"]

    def reset(self):
        self.xy = np.zeros(self.num_agents)
        if(self.dist > 1):
             self.state = list(self.state[:1]) + list(self.xy)
        return np.array(self.state)

    def sample_action(self):
        return np.random.randint(2, size=self.num_agents)

#    def step(self, a):
#        print("Use steps: multiagent environment.")

    def step(self, a):
        self.xy += np.array(a)
        arrived = self.xy >= self.dist
        inradius = self.xy >= (self.dist - self.radius + 1)
        done, reward = np.sum(arrived) >= 1, np.zeros(self.num_agents)
        done = done or self.dist == 1
        if (done and np.sum(inradius) == 1):
            int_arrived = 1 * arrived
            reward = self.high * int_arrived + self.low * 1 * (np.ones(self.num_agents) - arrived)

        if(not np.any(np.array(reward))): 
            self.state = [0]
        else:
            self.state = [np.argmax(np.array(reward))+1]

        if(self.dist > 1):
             self.state = np.array(self.state + list(self.xy))

        return self.state, reward, done, None

    def close(self):
        pass