import numpy as np
import matplotlib.pyplot as plt
import random
from enum import Enum
import sys
from insoco.Plotting import draw_layers            # python project folder is in sys path
from insoco.Environment import ACT_MODE, OBS_MODE, ACT_PLUS


class FinalGrid():

    def __init__(self, conf={}):
        self.conf = conf
        self.layers = {}
        self.fig = None

        self.moves = (np.array([0, -1]),np.array([0, 1]), np.array([-1, 0]), np.array([1, 0]))

        if "n" in conf:
            self.n = conf["n"]
            rows_cols = np.array([self.n, self.n])
        elif "rows" in conf and "cols" in conf:
            rows_cols = [conf["rows"], conf["cols"]]

        self.rows, self.cols = rows_cols
        self.rows_cols = np.array([self.rows, self.cols])
        self.n = self.rows

        self.obs_mode = OBS_MODE.GLOBAL
        if "obs_mode" in conf:
            self.obs_mode = conf["obs_mode"]
            if self.obs_mode not in [OBS_MODE.GLOBAL, OBS_MODE.GLOBAL_CENTER_PAD, OBS_MODE.GLOBAL_CENTER_WRAP]:
                self.obs_radius = 1
            else:
                self.obs_radius = int(self.n/2)

            if "obs_radius" in conf:
                self.obs_radius = conf["obs_radius"]

            if self.obs_mode in [OBS_MODE.LOCAL_ONE_HOT, OBS_MODE.LOCAL_SUM_ONE_HOT]:
                self.state_map = {}
                self.state_list = []

        self.action_mode = ACT_MODE.ALLOCENTRIC
        self.action_plus = ACT_PLUS.SAME
        if "action_mode" in conf: self.action_mode = conf["action_mode"]
        if "action_plus" in conf: self.action_plus = conf["action_plus"]

        self.num_agents = 1 if "num_agents" not in conf else conf["num_agents"]

        self.nactions = 4
        if self.action_mode is ACT_MODE.EGOCENTRIC:
            self.nactions = 3
        if "objects" in conf or "keys" in conf or "boxes" in conf:
            self.nactions += 1

        if self.action_plus in [ACT_PLUS.NOTHING_RANDOM, ACT_PLUS.NOTHING_RANDOM_HARVEST]:
            self.nactions = 2
            if self.action_plus == ACT_PLUS.NOTHING_RANDOM_HARVEST:
                self.nactions += 1

        if self.action_plus is ACT_PLUS.FOREST_FIRE:
            self.nactions += 1

        self.term_mode = []
        if "term_mode" in conf:
            self.term_mode = conf["term_mode"]
            if isinstance(self.term_mode,str):
                self.term_mode = [self.term_mode]

        if "walls" in conf:  
            if isinstance(conf["walls"],str):
                conf["walls"] = [conf["walls"]]

        if "floor" in conf:  
            if isinstance(conf["floor"],str):
                conf["floor"] = [conf["floor"]]
        else:
            self.floor = None

        self.torus = False if "torus" not in conf else conf["torus"]

        self.nepisode = 0
        obs = self.reset()
        self.observation_shape = obs.shape


    def reset(self):         # Environment can be reseted during a conf["run"] and stats may be wanted run["stats"]
        self.layers = {}
        conf = self.conf
        if "run" in conf:
            if "stats" in conf["run"]:
                self.stats = conf["run"]["stats"]

        if "walls" in conf:  self.add_walls(conf["walls"])
        if "boxes" in conf:  self.add_boxes(conf["boxes"])
        if "food" in conf:  self.add_food(conf["food"])
        if "floor" in conf:  self.add_floor(conf["floor"])
        if "objects" in conf:  self.add_objects(conf["objects"])

        if "blocks" in self.term_mode:
            good = self.layers["floor"] == self.layers["objects"]
            self.prev_reward = np.sum(good)

        if "update" in conf:
            if conf["update"] is "game_of_life":
                num = 10
                if "update_params" in conf:
                    if "ini_cells" in conf["update_params"]:
                        num = conf["update_params"]["ini_cells"]
                self.add_food(num)

            if conf["update"] is "forest_fire":
                conf["floor"] = []
                self.add_floor([])
                num = 10
                self.prob_fire, self.prob_tree, self.prob_harvest = 0.01, 0.1, 0.5
                if "update_params" in conf:
                    if "ini_cells" in conf["update_params"]:
                        num = conf["update_params"]["ini_cells"]
                    if "prob_fire" in conf["update_params"]:
                        self.prob_fire = conf["update_params"]["prob_fire"]
                    if "prob_tree" in conf["update_params"]:
                        self.prob_tree = conf["update_params"]["prob_tree"]
                    if "prob_harvest" in conf["update_params"]:
                        self.prob_harvest = conf["update_params"]["prob_harvest"]
                for _ in range(num):
                    x, y = np.random.randint(self.n, size=2)
                    self.floor[x%self.rows, y%self.cols] = 1

                if hasattr(self,"stats"):
                    self.stats["current_num_trees"] = 0
                    self.stats["current_num_fires"] = 0
                    self.stats["epi_trees_list"] = []
                    self.stats["epi_fires_list"] = []

        if "goal_sequence" in self.term_mode:
            self.current_goal = 1

        for i in range(self.num_agents):
            self.ini_agent(i)

        self.t = 0
        self.nepisode += 1

        if self.num_agents == 1:
            return self.generate_obs()
        else:
            obs = []
            for i in range(self.num_agents):
                self.agent_xy = self.agents_xy[i]
                if self.action_mode is ACT_MODE.EGOCENTRIC:
                    self.agent_dir = self.agents_dir[i]
                obs.append(self.generate_obs())
            return np.array(obs)

    def drop_action(self):
        x, y = self.agent_xy
        reward, done = 0, False
        if "objects" not in self.layers: return reward, done
        if self.objects[x,y] == 0: return reward, done         # to drop we need to carry something

        if(self.action_mode == ACT_MODE.ALLOCENTRIC):
            # implement
            return reward, done

        xn, yn = self.agent_xy + self.agent_dir
        if not self.free_cell([xn, yn]): return reward, done         # free cell so drop

        self.layers["objects"][xn,yn] = self.layers["objects"][x,y]
        self.layers["objects"][x,y] = 0

        if "floor" in self.conf:                 
            if "object_areas" in self.conf["floor"]:      # ants world
                nareas = self.conf["floor"]["object_areas"]
                obj = self.objects[xn,yn]
                ifloor = self.floor[xn,yn]
                if obj == ifloor:
                    reward += 1
                    self.objects[xn,yn] += 1
                    if self.objects[xn,yn] == nareas:              # reached end area
                        self.objects[xn,yn] = 0  # remove object

        return reward, done


    def is_move_valid(self,move):
        x,y = self.agent_xy
        xn,yn = self.agent_xy + move
        if self.torus:
            xn,yn = xn % self.rows, yn % self.cols

        valid_move = xn >= 0 and yn >= 0 and xn < self.rows and yn < self.cols

        if(not valid_move):
            return False

        valid_move = valid_move and self.layers["agents"][xn, yn] == 0
        if ("walls" in self.layers):
            valid_move = valid_move and self.layers["walls"][xn, yn] == 0

        if ("objects" in self.layers):
            valid_obj = self.layers["objects"][xn, yn] > 0 and self.layers["objects"][x, y] == 0
            valid_obj = valid_obj or self.layers["objects"][xn, yn] == 0
            valid_move = valid_move and valid_obj
        return valid_move

    def move_agent(self,move):
        reward, done = 0.0, False
        x,y = self.agent_xy
        xn,yn = self.agent_xy + move
        if self.torus:
            xn,yn = xn % self.rows, yn % self.cols

        self.layers["agents"][xn, yn] = self.layers["agents"][x, y]
        self.layers["agents"][x, y] = 0
        self.agent_xy = np.array([xn, yn])

        if ("objects" in self.layers):
            obj_old_pos = self.layers["objects"][x, y]
            if (obj_old_pos > 0):
                self.layers["objects"][x, y] = 0
                self.layers["objects"][xn, yn] = obj_old_pos

        if ("food" in self.layers):
            reward = self.layers["food"][xn, yn]
            self.layers["food"][xn, yn] = 0

        return reward, done

    def pick_action(self):
        x,y = self.agent_xy
        return 0, False

    def change_floor(self):
        x,y = self.agent_xy
        if "forest_fire" in self.term_mode:   # harvest
            r = self.obs_radius
            for rx in np.arange(-r,r+1,1):
                for ry in np.arange(-r,r+1,1):
                    if random.random() <= self.prob_harvest:                     
                        hx, hy = x+rx, y+ry
                        #if hx != x or hy != y:
                        if 0 <= hx < self.rows and 0 <= hy < self.cols:
                            if self.floor[hx, hy] == 1:
                                self.floor[hx, hy] = 0
        return 0, False


    def move_UpDownLeftRight(self,a):
        reward, done = 0.0, False
        if a < 4:
            move = self.moves[a]        # [0, -1],[0, 1],[-1, 0],[1, 0])
            if self.is_move_valid(move):
                reward, done = self.move_agent(move)

        elif (a == 4):
            if self.action_plus == ACT_PLUS.FOREST_FIRE:
                reward, done = self.change_floor()
            else:
                reward, done = self.pick_action()
        elif (a == 5):
            reward, done = self.drop_action()

        return reward, done

    def move_FwdTurn(self,a):
        reward, done = 0.0, False
        x, y = self.agent_xy
        dx, dy = self.agent_dir

        if a in [0,1]:
            if a == 0:
                self.agent_dir = np.array([-dy, dx])
                self.agents[x, y] += 1
                if (self.agents[x, y] >= 5):
                    self.agents[x, y] = 1
            elif a == 1:
                self.agent_dir = np.array([dy, -dx])
                self.agents[x, y] -= 1
                if (self.agents[x, y] == 0):
                    self.agents[x, y] = 4
        elif a == 2:
            move = self.agent_dir
            if self.is_move_valid(move):
                reward, done = self.move_agent(move)

        elif a == 3:
            if self.action_plus == ACT_PLUS.FOREST_FIRE:
                reward, done = self.change_floor()
            else:
                reward, done = self.drop_action()

        return reward, done


    def add_row_col_zero(self, ex, ey, z, state):
        if ex == 1 and ey == 1:
            z[:,:-1,:-1] = state
            return z
        elif ex == 1 and ey == 0:
            z[:,:-1,:] = state
            return z
        elif ex == 0 and ey == 1:
            z[:,:,:-1] = state
            return z

    def add_row_col_roll(self, ex, ey, z, state):
        if ex == 1:
            z[:,-1,:] = state[:,0,:]

        if ey == 1:
            z[:,:,-1] = state[:,:,0]

        return z

    def gridworld_center_view(self, padding=False, layers_names=None):
        # Gets rid of the agent layer as the state is centered and it is not informative
        if layers_names is None:
            layers_names = list(self.layers.keys() - ["agents"])

        rows_cols = self.rows_cols
        n_layers = len(layers_names)
        state = np.stack([self.layers[k] for k in layers_names])

        ex,ey = (rows_cols+1) % 2   # odd row, odd col
        pos = self.agent_xy
        center = (rows_cols-[1,1]+[ex,ey]) / 2.0
        cx, cy = center.astype(int)
        shift = (center - pos).astype(int)

        if padding:
            r = max(cx,cy)
            pad = ((0,0), (r,r), (r,r))    # No padding for the first dimension / feature channels
            state = np.pad(state, pad_width=pad, mode="constant", constant_values=0)

        centeredview = []
        for i in range(n_layers):  # if there is enough padding it shifts normally, otherwise it wraps around/rolls over
            centered = np.roll(state[i], shift, axis=(0,1))
            centeredview.append(centered)

        state = np.stack(centeredview)

        if any([ex,ey]) and self.obs_mode in [OBS_MODE.GLOBAL_CENTER_PAD, OBS_MODE.GLOBAL_CENTER_WRAP]:
            z = np.zeros(np.array(state.shape)+[0,ex,ey])
            state = self.add_row_col_zero(ex,ey,z,state)
            if self.torus:
                state = self.add_row_col_roll(ex,ey,z,state)

        return state

    def crop_radius(self, obs, r=1):
        layers = []
        center = np.array(obs.shape[1:])/2
        cx, cy = int(center[0]), int(center[1])  # How much to pad each side, distance from center is enough to shift the whole state without rolling over
        for i,o in enumerate(obs):
            l = [int(cx - r), int(cx + r + 1), int(cy - r), int(cy + r + 1)]
            sight = o[l[0]:l[1],l[2]:l[3]]
            if self.action_mode == ACT_MODE.EGOCENTRIC:
                x, y = self.agent_xy
                d = int(self.layers["agents"][x,y])
                for _ in range(d-1):
                    sight = np.rot90(sight,axes=(0,1))
            layers.append(sight)

        return np.stack(layers)


    def sum_radius(self, obs, r=1):
        sumv = []
        for i,o in enumerate(obs):
            c = int(o.shape[0]/2)
            sumv += [int(o[c,c])]
        if r>0:
            for i,o in enumerate(obs):
                for v in [1,2]:
                    x = 0 if o[c,c] != v else 1
                    s = np.sum(o == v) - x
                    sumv += [s]

        return np.array(sumv)

    def sum_radius_moore(self, obs, r=1):
        sumv = []
        c = int(obs[0].shape[0] / 2)  # obs shape is always squared (nxn) and odd n%2 == 1
        for i,o in enumerate(obs):
            sumv += [o[c,c]]
        if r>0:
            sumv += [o[c+1,c]]
            sumv += [o[c,c+1]]
            sumv += [o[c+1,c+1]]
            sumv += [o[c+1,c-1]]
            sumv += [o[c-1,c+1]]
            sumv += [o[c-1,c]]
            sumv += [o[c,c-1]]
            sumv += [o[c-1,c-1]]

        if r>1:
            for i,o in enumerate(obs):
                for v in [1]:
                    s1 = np.sum(o[c+1:,:]==v)
                    s2 = np.sum(o[:c,:]==v)
                    s3 = np.sum(o[:,c+1:]==v)
                    s4 = np.sum(o[:,:c]==v)
                    sumv += [s1,s2,s3,s4]

        return np.array(sumv).astype(int)

    def sum_radius_onion(self, obs, r=1):
        c = int(obs[0].shape[0] / 2)  # needs to be the agent one: obs shape is always squared (nxn) and odd n%2 == 1
        values = [1, 2]  # values to track in the observation / for forest fire 1 (tree) and 2 (fire)
        l = len(values)
        obs_sum = [0] * l
        sub_sum = np.array(obs_sum)
        for o in obs:
            for i in range(r + 1):  # i index for radius 0..r
                r_sum = []
                ii = r - i
                for v in values:
                    if i == 0:
                        r_sum += [np.sum(o[c, c] == v)]
                    elif i == r:
                        r_sum += [int(np.sum(o == v))]
                    else:
                        r_sum += [int(np.sum(o[ii:-ii, ii:-ii] == v))]

                sub_sum += np.array(obs_sum[-l:])
                obs_sum += list(np.array(r_sum) - sub_sum)

        obs_sum = np.array(obs_sum[l:]).astype(int)
        return obs_sum


    def one_hot_radius(self, obs, r=1, max_states=100):
        o = tuple(obs.flatten())
        if o not in self.state_map:
            if len(self.state_list) >= max_states-1:
                print("ONE_HOT: Reached", max_states, "stored states -------------------------------------------------")
            self.state_map[o] = len(self.state_list) % max_states
            self.state_list += [o]
        obs = np.zeros(max_states)
        obs[ self.state_map[o] ] = 1
        return obs


    def one_hot_sum_radius(self, obs, r=1, max_states=100):
        obs = self.sum_radius(obs, r=self.obs_radius)
        return self.one_hot_radius(obs, r=r, max_states=max_states) 


    def generate_obs(self):
        if self.obs_mode is OBS_MODE.GLOBAL:
            return np.stack(list(self.layers.values()))
        elif self.obs_mode is OBS_MODE.GLOBAL_CENTER_PAD:
            return self.gridworld_center_view(padding=True)
        elif self.obs_mode is OBS_MODE.GLOBAL_CENTER_WRAP:
            return self.gridworld_center_view(padding=False)

        layers_names = list(self.layers.keys() - ["agents"])

        if self.obs_radius < 1 and self.num_agents <= 1:
            layers_names = self.layers.keys() - set(["agents"])
            layers_names -= set(["walls"])
            layers_names = list(layers_names)

        bPad = not self.torus
        obs = self.gridworld_center_view(padding=bPad, layers_names=layers_names)

        max_states = 100*(self.obs_radius*self.obs_radius)


        obs = self.crop_radius(obs, r=self.obs_radius)
        if self.obs_mode == OBS_MODE.LOCAL:
            return obs
        elif self.obs_mode == OBS_MODE.LOCAL_SUM:
            return self.sum_radius(obs, r=self.obs_radius)
        elif self.obs_mode == OBS_MODE.LOCAL_ONE_HOT:
            return self.one_hot_radius(obs, r=self.obs_radius, max_states=max_states)
        elif self.obs_mode == OBS_MODE.LOCAL_SUM_ONE_HOT:
            return self.one_hot_sum_radius(obs, r=self.obs_radius, max_states=max_states)
        elif self.obs_mode == OBS_MODE.LOCAL_SUM_MOORE:
            return self.sum_radius_moore(obs, r=self.obs_radius)
        elif self.obs_mode == OBS_MODE.LOCAL_SUM_ONION:
            return self.sum_radius_onion(obs, r=self.obs_radius)

    def check_term(self, reward, done):
        x, y = self.agent_xy    # think it as rows,cols: x is in the y axis
        if "goal_sequence" in self.term_mode:
            if self.layers["floor"][x,y] == self.current_goal:
                self.layers["floor"][x,y] = 0
                self.current_goal += 1
                reward += 1
            done = done or self.current_goal == 4
            reward += 9

        if "empty" in self.term_mode:
            if "objects" in self.layers:
                done = done or np.count_nonzero(self.layers["objects"]) == 0
            if "food" in self.layers:
                done = done or np.count_nonzero(self.layers["food"]) == 0

        if "floor_exit" in self.term_mode:
            done = done or self.layers["floor"][x,y] == 2
            if(done):
                reward += 1

        if "forest_fire" in self.term_mode:
            x_old, y_old = self.agent_xy_old
            if self.floor[x_old, y_old] == 2 and self.floor_old[x, y] == 2:
                reward -= 10
            if self.layers["floor"][x, y] == 2:
                reward -= 10
            if self.layers["floor"][x, y] in [1,3]:
                reward += 0.5   


        if "counting" in self.term_mode:
            i = np.sum(self.layers["floor"][:, 0])
            done = done or (y == 1 and x == i-1)
            if done:
                reward += 1
            elif y == 1:
                reward -= 1

        if "blocks" in self.term_mode:
            good = self.layers["floor"] == self.layers["objects"]
            done = done or good.all()
            r = np.sum(good)
            if r > self.prev_reward:
                reward += r - self.prev_reward
                self.prev_reward = r

        if "harlow" in self.term_mode:
            bReward = self.nepisode % 10 < 5
            if self.floor[x,y] == 4:
                reward -= 3

            elif self.floor[x, y] == 1:
                self.floor[x, y] = 0
                self.layers["floor"] = self.floor
                if bReward:
                    reward += 10

            elif self.floor[x,y] == 3:
                self.floor[x, y] = 0
                self.layers["floor"] = self.floor
                if not bReward:
                    reward += 10

            done = done or self.floor[x,y] == 2

        return reward, done


    def step(self, a):
        if self.num_agents == 1:
            self.agent_xy_old = self.agent_xy.copy()
            self.t += 1
            self.update()
        elif not hasattr(self, 'agent_xy_old'):            # multiagent env but not using steps!
                self.agent_xy_old = self.agent_xy.copy()

        if self.action_plus in [ACT_PLUS.NOTHING_RANDOM, ACT_PLUS.NOTHING_RANDOM_HARVEST]:
            if a == 1:  # do random action
                if self.action_mode == ACT_MODE.ALLOCENTRIC:
                    a = np.random.randint(4)
                elif self.action_mode == ACT_MODE.EGOCENTRIC:
                    a = np.random.randint(3)
            else:
                reward, done = 0, False
                if a == 2:
                    self.change_floor() # harvest

                a = -1;  # do nothing for ACT_MODE: harvest or do nothing a=0

        if a >= 0:
            if self.action_mode == ACT_MODE.ALLOCENTRIC:
                reward, done = self.move_UpDownLeftRight(a)
            elif self.action_mode == ACT_MODE.EGOCENTRIC:
                reward, done = self.move_FwdTurn(a)

        reward, done = self.check_term(reward, done)
        reward -= 0.1

        obs = self.generate_obs()
        return obs, reward, done, None

    def steps(self, a_vector):
        self.t += 1
        self.agents_xy_old = self.agents_xy.copy()
        self.update()

        done = False
        rews = np.array([0.0]*self.num_agents)
        agents_list = list(enumerate(a_vector))
        random.shuffle(agents_list)
        for i, a in agents_list:
            self.agent_xy = self.agents_xy[i]
            self.agent_xy_old = self.agent_xy.copy()
            if self.action_mode is ACT_MODE.EGOCENTRIC:
                self.agent_dir = self.agents_dir[i]
            _, r, d, _ = self.step(a)
            done = done or d
            rews[i] = r

            self.agents_xy[i] = self.agent_xy
            if self.action_mode is ACT_MODE.EGOCENTRIC:
                self.agents_dir[i] = self.agent_dir

        self.agent_xy = self.agents_xy[0]            # We take as representative the 0 agent
        if self.action_mode is ACT_MODE.EGOCENTRIC:
            self.agent_dir = self.agents_dir[0]

        states = []
        for i, a in enumerate(a_vector):
            self.agent_xy = self.agents_xy[i] 
            if self.action_mode is ACT_MODE.EGOCENTRIC:
                self.agent_dir = self.agents_dir[i]
            states.append(self.generate_obs())

        return states, np.array(rews), done, _

    def free_cell(self, xy, check_layers = ["agents", "walls", "food", "objects"]):
        x, y = xy  
        free = x >= 0 and y >= 0 and x < self.rows and y < self.cols
        if(not free): return False
        for lstr in check_layers:
                if (lstr in self.layers):
                    free = free and self.layers[lstr][x, y] == 0
        return free

    def find_free_cell(self, check_layers=["agents", "walls", "food", "objects", "floor"]):
        valid = False
        while not valid:
            x = np.random.randint(self.rows)
            y = np.random.randint(self.cols)
            valid = True
            for lstr in check_layers:
                if (lstr in self.layers):
                    valid = valid and self.layers[lstr][x, y] == 0
        return x, y

    def ini_agent(self, i=0):
        if ("agents" not in self.layers):
            self.agents = np.zeros([self.rows, self.cols])
            self.agents_xy = self.num_agents * [0]
            if self.action_mode is ACT_MODE.EGOCENTRIC:
                self.agents_dir = self.num_agents * [1, 0]
            self.layers["agents"] = self.agents

        check_layers = ["agents", "walls", "food", "objects", "floor"]
        if self.rows * self.cols <= 9:
            if "blocks" in self.term_mode:
                check_layers = ["agents", "objects"]

        x, y = self.find_free_cell(check_layers=check_layers)
        if "counting" in self.term_mode:            
            x,y = 0,0

        self.agents_xy[i] = np.array([x, y])
        if self.action_mode is ACT_MODE.EGOCENTRIC:
            self.agents_dir[i] = np.array([1, 0])

        self.agent_xy = self.agents_xy[0]
        if self.action_mode is ACT_MODE.EGOCENTRIC:
            self.agent_dir = self.agents_dir[0]

        self.agents[x, y] = 1


    def add_floor(self, mode):
        self.floor = np.zeros([self.rows, self.cols])
        self.layers["floor"] = self.floor

        if "two_areas" in mode:
            c = mode["two_areas"]
            self.floor[:,c:] = 1

        if "hotel" in mode:
            self.floor[:,:] = 1
            self.floor[int(self.rows/2),-1] = 2
            self.floor[int(self.rows/2),0] = 0

        if "exit" in mode:
            self.floor[int(self.rows/2), -3] = 2
  
        if "object_areas" in mode:
            a = mode["object_areas"]
            if (self.n % a == 0):
                self.floor[int(self.n / a):int(2 * self.n / a), :] = 1
                self.floor[int(2 * self.n / 3):, :] = 2
            elif (self.n % 2 == 0):
                self.floor[int(self.n / 2):, :] = 1

        if "goal_sequence" in mode:
            ng = mode["goal_sequence"]
            for g in range(ng):
                x, y = np.random.randint(self.n, size=2)
                x, y = x%self.rows, y%self.cols
                while self.floor[x, y] > 0:
                    x, y = np.random.randint(self.n, size=2)
                    x, y = x%self.rows, y%self.cols
                self.floor[x, y] = g+1

        if "counting" in mode:
            i = np.random.randint(self.rows)+1
            for _ in range(i):
                j = np.random.randint(self.rows)
                while self.floor[j, 0] > 0:
                    j = np.random.randint(self.rows)
                self.floor[j, 0] = 1

        if "blocks" in mode:
            if "objects" not in self.conf:
                print("Blocks World termination mode needs key objects:num")
                sys.exit(0)

            nobj = self.conf["objects"]
            ncolors = self.rows
            for _ in range(nobj):
                i = self.cols-1
                while not any(self.floor[:,i] == 0):
                    i -= 1

                j = np.random.randint(self.rows)
                while self.floor[j, i] > 0:
                    j = np.random.randint(self.rows)

                self.floor[j, i] = np.random.randint(ncolors)+1

        if "harlow" in mode:
            self.floor += 4
            self.floor[-1,int(self.cols / 2)] = 0
            self.floor[-1,0] = 1
            self.floor[-1,-1] = 2
            self.floor[0,int(self.cols / 2)] = 3


    def add_objects(self, num):
        self.nobjects = num
        self.objects = np.zeros([self.rows, self.cols])
        self.layers["objects"] = self.objects
        for _ in range(num):
            check_layers = ["agents", "walls", "food", "objects", "floor"]
            if "blocks" in self.term_mode:
                if self.cols < 4:
                    check_layers.remove("floor")

            i, j = self.find_free_cell(check_layers=check_layers)
            self.objects[i, j] = 1

        if "blocks" in self.term_mode:
            r = int(self.rows/2-1)
            l = list(map(int,self.floor[r:,:].flatten()))
            while 0 in l :
                l.remove(0)

            iobjs,jobjs = np.nonzero(self.objects)
            for i,j in zip(iobjs,jobjs):
                self.objects[i,j] = l.pop()


    def add_food(self, num):
        self.food = np.zeros([self.rows, self.cols])
        self.layers["food"] = self.food
        for _ in range(num):
            valid = False
            while not valid:
                x, y = np.random.randint(self.n, size=2)
                valid = self.food[x, y] == 0
                if "walls" in self.layers:
                    valid = valid and self.walls[x, y] == 0
            self.food[x, y] = 1

    def add_walls(self, mode):
        self.walls = np.zeros([self.rows, self.cols])

        if "hotel" in mode:
            self.walls[int(self.rows/2), int(self.cols/2)] = 1
        else:
            self.walls = np.ones([self.rows, self.cols])
            self.walls[1:-1, 1:-1] = 0

        if "two_tunnels" in mode:
            #self.walls[int(self.rows/2), 0] = 0            
            self.walls[int(self.rows/2)-2, 0] = 0            
            self.walls[int(self.rows/2)+2, 0] = 0            

            self.walls[1, 1:-3] = 1
            self.walls[2, 2:-3] = 1

            self.walls[-2, 1:-3] = 1
            self.walls[-3, 2:-3] = 1

            r = int(max(0,self.rows-11)/2)
            self.walls[int((self.rows-1)/2)-1-r:int((self.rows-1)/2)+2+r, 3:-3] = 1

        self.layers["walls"] = self.walls

    def add_boxes(self, mode):
        self.boxes = np.zeros([self.rows, self.cols])
        self.layers["boxes"] = self.boxes

        self.inside_box = np.zeros([self.rows, self.cols])
        if (self.n == 3):
            self.boxes[1, 1] = 1
        elif (self.n == 5):
            box_pos = [(1, 1), (3, 3), (1, 3), (3, 1)]
            rows, cols = zip(*box_pos)
            self.boxes[rows, cols] = 1


    def update(self):
        if "update" not in self.conf:
            return

        bUpdate, step_freq, steps = True, 1, 1
        if "update_params" in self.conf:
            params = self.conf["update_params"]
            if "step_freq" in params:
                step_freq = params["step_freq"]

        if self.conf["update"] is "forest_fire":
            x_old, y_old = self.agent_xy
            self.floor_xy_old = self.floor[x_old, y_old]

        bUpdate = True if step_freq <=0 else (self.t % step_freq) == 0
        if bUpdate:
            if step_freq <= 0:
                steps = abs(step_freq)+1
            for _ in range(steps):
                if self.conf["update"] is "game_of_life":
                    self.update_gol()
                if self.conf["update"] is "forest_fire":
                    self.update_forest()


    def update_gol(self):
        grid = self.layers["food"]
        new_grid = self.layers["food"].copy()
        N, M = self.rows, self.cols
        for i in range(N):
            for j in range(M):
                total = grid[i, (j-1)%N] + grid[i, (j+1)%N] + grid[(i-1)%N, j] + grid[(i+1)%N, j] + grid[(i-1)%N, (j-1)%N] + grid[(i-1)%N, (j+1)%N] + grid[(i+1)%N, (j-1)%N] + grid[(i+1)%N, (j+1)%N]

                if grid[i, j] == 1:
                    if (total < 2) or (total > 3):
                        new_grid[i, j] = 0
                else:
                    if total == 3:
                        if self.free_cell([i, j]):
                            new_grid[i, j] = 1

        grid[:] = new_grid[:] 

    def get_layer(self, name):
        if name in self.layers:
            return self.layers[name]
        else:
            print("Error Layer does not exist")
            return None

    def update_forest(self):
        grid = self.floor
        grid_old = grid.copy()
        self.floor_old = grid_old

        N, M = self.rows, self.cols

        if hasattr(self,"stats"):
            self.stats["current_num_trees"] = 0
            self.stats["current_num_fires"] = 0

        for i in range(N):
            for j in range(M):
                if grid_old[i, j] == 2:
                    grid[i, j] = 0
                elif grid_old[i, j] == 0:
                    grid[i, j] = 0
                    if random.random() <= self.prob_tree:
                        grid[i, j] = 1
                elif grid_old[i, j] == 1:
                    grid[i, j] = 1
                    if random.random() <= self.prob_fire:
                        grid[i, j] = 2
                    else:
                        neigh_fire = any(grid_old[max(0,i-1):i+2,max(0,j-1):j+2].flatten() == 2)
                        if self.torus:
                            neigh_fire = any(grid_old[max(0,i-1):i+2,max(0,j-1):j+2].flatten() == 2)

                            if i == 0:
                                neigh_fire = neigh_fire or any(grid_old[-1:,max(0,j-1):j+2].flatten() == 2)
                            if j == 0:
                                neigh_fire = neigh_fire or any(grid_old[max(0,i-1):i+2,-1:].flatten() == 2)
                            if i == N-1:
                                neigh_fire = neigh_fire or any(grid_old[:1,max(0,j-1):j+2].flatten() == 2)
                            if j == M-1:
                                neigh_fire = neigh_fire or any(grid_old[max(0,i-1):i+2,:1].flatten() == 2)

                        if neigh_fire:
                            grid[i, j] = 2

                if hasattr(self,"stats"):
                    if grid[i,j] == 1:
                        self.stats["current_num_trees"] += 1
                    elif grid[i,j] == 2:
                        self.stats["current_num_fires"] += 1

        if N == 3:
            grid[1, 1] = 0

        self.layers["floor"] = grid


    def stats_ini(self):
        if self.conf["update"] is "forest_fire":
            self.stats["epi_trees_list"] = []
            self.stats["epi_fires_list"] = []

    def stats_update(self):
        if self.conf["update"] is "forest_fire":
            self.stats["epi_trees_list"] += [self.stats["current_num_trees"]]
            self.stats["epi_fires_list"] += [self.stats["current_num_fires"]]


    def plot_ascii(self):
        print("shape of state:", np.array(list(self.layers.values())).shape, "\n")
        for k, layer in self.layers.items():
            print("----------------------", k, ":")
            print(layer)
            print(" ")

    def render(self, param=None):
        draw_layers(self.conf, self.layers)
        if(param is not None): 
            fig = param
            self.fig = fig
            fig.canvas.draw()

    def close(self):
        pass

