import numpy as np
import sys
import math

from gym.envs.toy_text import discrete


class RockScissorsPaper(discrete.DiscreteEnv):
    """ RockScissorsPaper agains a random distribution agent
    """

    def __init__(self):
        """ The environment is a DiscreteEnv 
        """
        nS,nA = 3,3

        d = np.random.random(3)
        d[ np.random.randint(3) ] += 0.15
        d = d / d.sum()
        self.probs = d

        ROCK,SCISSORS,PAPER = 0,1,2

        rmat = np.zeros([3,3])

        rmat[ROCK][PAPER] = -1        
        rmat[ROCK][SCISSORS] = 1        
        rmat[PAPER][ROCK] = 1        
        rmat[PAPER][SCISSORS] = -1        
        rmat[SCISSORS][ROCK] = -1        
        rmat[SCISSORS][PAPER] = 1        

        P = {}
        for s in [0,1,2]:
            P[s] = { a : [] for a in range(nA) }
            for a in [0,1,2]:
                for s_new in [0,1,2]:
                    P[s][a].append([d[s_new], s_new, rmat[a][s_new], False])

        self.shape = (1)

        self.nsteps = 0

        isd = np.zeros(nS)
        isd[0] = 1.0
        super(RockScissorsPaper, self).__init__(nS, nA, P, isd)

    def step(self,action):
        s,r,done,info = super(RockScissorsPaper,self).step(action)
        self.nsteps += 1
        if(self.nsteps == 10):
            done = True
            self.nsteps = 0
        return s,r,done,info

    def render(self):
        if(self.s == 0):  print("State is ROCK"); 
        if(self.s == 1):  print("State is SCISSORS"); 
        if(self.s == 2):  print("State is PAPER"); 
        print("Opponent probs of Rock, Scissors, Paper:",self.probs)

