import sys
import matplotlib
import matplotlib.pyplot as plt
import numpy as np

from Environment import Environment
import env_confs

#conf = env_confs.conf_tunnels
#conf = env_confs.conf_hotel
conf = env_confs.conf_food
#conf = env_confs.conf_seq
#conf = env_confs.conf_ants
#conf = env_confs.conf_counting
#conf = env_confs.conf_blocks
#conf = env_confs.conf_gol
#conf = env_confs.conf_ff
#conf = env_confs.conf_ff_3x3
#conf= env_confs.conf_harlow
#conf = env_confs.conf_greed

num_agents = 1 if "num_agents" not in conf else conf["num_agents"]
env = Environment(conf)
fig = plt.figure(figsize=(7,7))
env.set_figure(fig)
sum_rew = None

#print(env.reset())


def keyDown(event):
    global env, fig, sum_rew, num_agents, conf

    if event.key == 'escape': sys.exit(0)

    action = 0
    if event.key == 'left':   action = 0
    elif event.key == 'right':  action = 1
    elif event.key == 'up':  action = 2
    elif event.key == 'down':  action = 3
    elif event.key == ' ':  action = 4
    elif event.key == '1':  conf = env_confs.conf_tunnels
    elif event.key == '2':  conf = env_confs.conf_hotel
    elif event.key == '3':  conf = env_confs.conf_seq
    elif event.key == '4':  conf = env_confs.conf_ants
    elif event.key == '5':  conf = env_confs.conf_counting
    elif event.key == '6':  conf = env_confs.conf_blocks
    elif event.key == '7':  conf = env_confs.conf_gol
    elif event.key == '8':  conf = env_confs.conf_ff
    elif event.key == '9':  conf = env_confs.conf_ff_3x3

    if event.key in ['1','2','3','4','5','6','7','8','9']:
        num_agents = 1 if "num_agents" not in conf else conf["num_agents"]
        env = Environment(conf)
        env.reset()
        env.set_figure(fig)
        sum_rew = None

    if(num_agents == 1):
        obs, reward, done, info = env.step(action)
    else:
        actions = [action] + list(np.random.randint(4,size=num_agents-1))
        obs, reward, done, info = env.steps(actions)

    sum_rew = np.array(reward) if sum_rew is None else sum_rew + np.array(reward)

    if num_agents == 1:
        print(obs)
    else:
        print(obs)

    if done:
        print("Reward: ", reward, "Episode Terminated     Total Reward: ", sum_rew)
        sum_rew = None
        obs = env.reset()
    else:
        print("Reward: ", reward)

    env.render()
    #fig.savefig("imgs/"+conf["name"]+"_"+conf["floor"],dpi=300)

fig.canvas.mpl_connect('key_press_event', keyDown)
env.render()
plt.show()






