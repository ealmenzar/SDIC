from insoco.Environment import ACT_MODE, ACT_PLUS, OBS_MODE

conf_tunnels = {"name": "FinalGrid",
        "rows": 11, "cols": 9,
        "max_steps": 100,
        "num_agents": 1,
        "action_mode": ACT_MODE.EGOCENTRIC,
        "obs_mode": OBS_MODE.LOCAL_ONE_HOT,
        "obs_radius": 1,
        "walls": "two_tunnels",
        "floor": {"two_areas":1, "exit":1},
        "term_mode": "floor_exit"
        }

conf_hotel = {"name": "FinalGrid",
        "rows": 3, "cols": 3,
        "floor": "hotel",
        "walls": "hotel",
        "term_mode": "floor_exit",
        "obs_mode": OBS_MODE.LOCAL,
        "obs_radius": 0,
        "action_mode": ACT_MODE.EGOCENTRIC,
        }


conf_ants = {"name": "FinalGrid",
        "n": 9,
        "num_agents": 2,
        "action_mode": ACT_MODE.EGOCENTRIC,
        "obs_mode": OBS_MODE.LOCAL,
        "objects": 5,
        "floor": {"object_areas":3},
        "term_mode": "empty"
        }


conf_food = {"name": "FinalGrid",
        "num_agents":1,
        "rows": 5, "cols": 5,
        "food": 10,
        "action_mode": ACT_MODE.EGOCENTRIC,
        "obs_mode": OBS_MODE.GLOBAL,
        "term_mode": "empty"
        }

conf_seq = {"name": "FinalGrid",
        "n": 5,
        "floor": {"goal_sequence":3},
        "term_mode": "goal_sequence"
        }

conf_gol = {"name": "FinalGrid",
        "num_agents": 3,
        "n": 10,
        "update": "game_of_life",
        "update_params": {"step_freq":-1, "ini_cells":25},
        "term_mode": "empty",
        "obs_mode": OBS_MODE.LOCAL,
        "action_mode": ACT_MODE.EGOCENTRIC,
        }

conf_ff_3x3 = {"name": "FinalGrid",
        "num_agents": 1,
        "max_steps":200,
        "n": 3,
        "update": "forest_fire",
        "update_params": {"ini_cells":1, "prob_fire":0.01, "prob_tree":0.1},
        "term_mode": "forest_fire",
        "obs_mode": OBS_MODE.GLOBAL,
        "action_mode": ACT_MODE.ALLOCENTRIC,
        "action_plus": ACT_PLUS.FOREST_FIRE,
        }

conf_ff = {"name": "FinalGrid",
        "num_agents": 2,
        "rows": 10,
        "cols": 10,
        "torus": True,
        "update": "forest_fire",
        "update_params": {"prob_fire":0.005, "prob_tree":0.06, "prob_harvest":0.4},
        "term_mode": "forest_fire",
        "obs_mode": OBS_MODE.LOCAL_SUM_ONION,
        "obs_radius": 2,
        "action_mode": ACT_MODE.ALLOCENTRIC,
        "action_plus": ACT_PLUS.NOTHING_RANDOM_HARVEST,
        "max_steps":100
        }

conf_counting = {"name": "FinalGrid",
        "rows": 9, "cols": 2,
        "floor": "counting",
        "term_mode": "counting",
        "obs_mode": OBS_MODE.GLOBAL,
        "action_mode": ACT_MODE.ALLOCENTRIC,
        }

conf_blocks = {"name": "FinalGrid",
        "max_steps":10000,
        "rows": 3, "cols": 3,
        "floor": "blocks",
        "term_mode": "blocks",
        "objects": 5,
        "obs_mode": OBS_MODE.GLOBAL,
        "action_mode": ACT_MODE.EGOCENTRIC,
        }


conf_harlow = {"name": "FinalGrid",
        "max_steps": 12,
        "n": 3,
        "floor": "harlow",
        "term_mode": "harlow",
        "obs_mode": OBS_MODE.GLOBAL,
        "action_mode": ACT_MODE.ALLOCENTRIC,
        }


conf_greed = {"name": "FinalGrid",
        "n": 4,
        "food": 2,
        "action_mode": ACT_MODE.ALLOCENTRIC,
        "obs_mode": OBS_MODE.GLOBAL,
        "term_mode": "empty"
        }

conf_smooth = {"name": "FinalGrid",
        "n": 4,
        "food": 2,
        "action_mode": ACT_MODE.ALLOCENTRIC,
        "obs_mode": OBS_MODE.GLOBAL,
        "term_mode": "empty"
        }

conf_multiagent = {"name": "FinalGrid",
        "rows": 9, "cols": 9,
        "num_agents": 6,
        "food": 20,
        "obs_mode": OBS_MODE.LOCAL,
        "action_mode": ACT_MODE.EGOCENTRIC,
        "obs_radius": 3,
        "term_mode": "empty"
        }
