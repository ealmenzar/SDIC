""" course: System Design Integration and Control SDIC, CSIM, UPF
    contact: marti.sanchez@upf.edu
    Environment.py : Wraper class for OpenAI-Gym python.environments
    and other defined here;
    "BlackJack" : Sutton and Barto Book
    "CliffWalking" : Sutton and Barto Book
    "GridworldSutton" : Sutton and Barto Book
    "WindyGridworld" : Sutton and Barto Book
    "SuttonSimplest" : Simple MDP, Sutton talk
    "BattleExes" : multi agent grid version of Battle of the Sexes
    "FruitCollection" : SuperMini,Mini,Small,Large
    "JackCarRental" : Sutton and Barto Book
    "BimanualRobot" : PyBox2d simulation (not an environment yet)
    "KeyCollection" : Hierarchical key collection
    "Wisconsin" : Wisconsin card test
"""


import sys
from ast import literal_eval

import gym
import numpy as np
from gym.envs.toy_text import discrete
from gym.spaces import Discrete, Box


from enum import Enum



class OBS_MODE(Enum):
    GLOBAL = 0
    GLOBAL_CENTER_PAD = 1
    GLOBAL_CENTER_WRAP = 2
    LOCAL = 3
    LOCAL_SUM = 4
    LOCAL_ONE_HOT = 5
    LOCAL_SUM_ONE_HOT = 6
    LOCAL_SUM_MOORE = 7
    LOCAL_SUM_ONION = 8



class ACT_MODE(Enum):
    ALLOCENTRIC = 0
    EGOCENTRIC = 1

class ACT_PLUS(Enum):
    SAME = 0
    PLUS_DO_NOTHING = 1
    NOTHING_RANDOM = 2   # do nothing or move random according to ACT_MODE
    NOTHING_RANDOM_HARVEST = 3   # not move, random, harvest
    FOREST_FIRE = 4             # add harvest to ACT_MODE


class Environment():

    def filter_params(self, NameOrParams):
        self.envs_names = ["BlackJack","CliffWalking","GridworldSutton","WindyGridworld","SuttonSimplest","BattleExes","BimanualRobot"]
        self.conf = None        
        self.max_steps = 100000
        self.discretize_action = 0
        self.multi_agent_mode = 1

        if isinstance(NameOrParams,dict):
            in_conf = NameOrParams 
            if(not "name" in in_conf):
                print("Error: Environment config dictionnary must include env name: {\"name\":\"....\"")
                return False
            if(not "max_steps" in in_conf):
                print("Setting default max_steps per episode: %d"%self.max_steps)
            if(not "num_agents" in in_conf):
                self.num_agents = 1
                print("Default number of agents: %d"%self.num_agents)

            self.conf = in_conf
            self.__dict__.update(**in_conf)   # translate dictionnary into class attributes 
            self.basename = self.name

        if isinstance(NameOrParams,str):
            print("Setting default max_steps per episode: %d"%self.max_steps)
            self.name = NameOrParams
            self.basename = self.name.split('-')[0]
 
        return True

    def __init__(self, NameOrParams):

        if(not self.filter_params(NameOrParams)):
            return

        params = None if len(self.name.split('-')) == 1 else self.name.split('-')[1:]
        name,basename = self.name,self.basename
        self.fig = None
        
        envids = [spec.id for spec in gym.envs.registry.all()]
        if (name in envids):
            print(name,"is an openai gym registered environment")
            self.my_env = gym.make(name)

        # The environment is not a gym environment
        elif(basename == "BlackJack"):
            from insoco.environments.blackjack import BlackjackEnv
            self.my_env = BlackjackEnv()

        elif(basename == "CliffWalking"):
            from insoco.environments.cliff_walking import CliffWalkingEnv
            self.my_env = CliffWalkingEnv()

        elif(basename == "GridworldSutton"):
            from insoco.environments.gridworld_sutton import GridworldSuttonEnv
            self.my_env = GridworldSuttonEnv()
        
        elif(basename == "WindyGridworld"):
            from insoco.environments.windy_gridworld import WindyGridworldEnv
            self.my_env = WindyGridworldEnv()
        
        elif(basename == "SuttonSimplest"):
            from insoco.environments.suttonsimplest import SuttonSimplestEnv
            self.my_env = SuttonSimplestEnv()
        
        elif(basename == "RockScissorsPaper"):
            from insoco.environments.rockscissorspaper import RockScissorsPaper
            self.my_env = RockScissorsPaper()

        elif(basename == "BattleExes"):
            from insoco.environments.battle_of_exes import BattleOfExesEnv
            self.my_env = BattleOfExesEnv()

        elif(basename == "BattleExesMin"):
            from insoco.environments.battle_of_exes import BattleOfExesMin
            self.my_env = BattleOfExesMin(self.conf)
            obs = self.my_env.reset()
            self.my_env.observation_space = Box(low=np.inf, high=np.inf, shape = obs.shape, dtype=np.int)
            self.my_env.action_space= Discrete(2)

        elif(basename == "FruitCollection"):
            from insoco.environments.fruit_collection import FruitCollectionSuperMini, FruitCollectionMini, FruitCollectionSmall, FruitCollectionLarge
            bRender = True
            bFruit, bGhost = True, False                
            if(len(params) == 2):
                bFruit = literal_eval(params[0])
                bGhost = literal_eval(params[1])
            if(len(params) == 3):
                bFruit = literal_eval(params[1])
                bGhost = literal_eval(params[2])

            if(len(params) in [1,3]):
                    if(params[0] == "SuperMini"): self.my_env = FruitCollectionSuperMini(lives=1, rendering=bRender, is_fruit=bFruit,is_ghost=bGhost)
                    if(params[0] == "Mini"): self.my_env = FruitCollectionMini(lives=1, rendering=bRender, is_fruit=bFruit,is_ghost=bGhost)
                    if(params[0] == "Small"): self.my_env = FruitCollectionSmall(lives=1, rendering=bRender, is_fruit=bFruit,is_ghost=bGhost)
                    if(params[0] == "Large"): self.my_env = FruitCollectionLarge(lives=1, rendering=bRender, is_fruit=bFruit,is_ghost=bGhost)
            else:
                self.my_env = FruitCollectionSmall(lives=1, rendering=bRender, is_fruit=bFruit,is_ghost=bGhost)

            self.my_env.reset()
            obs = self.my_env.get_state()
            self.my_env.observation_space = Box(low=-np.inf, high=np.inf, shape=obs.shape, dtype=np.float32)
            self.my_env.action_space = Discrete(4)
            print("FruitCollection ", self.my_env.scr_w,"x",self.my_env.scr_h, " created. With fruits:", self.my_env.is_fruit,"  With ghosts:",self.my_env.is_ghost)

            if(bRender): self.my_env.render()

        elif (basename == "KeyCollection"):
            from insoco.environments.key_collect import KeyCollection
            bRender = True
            bKeys = 3
            bSize = 5
            if (len(params) == 2):
                bKeys = literal_eval(params[0])
                bSize = literal_eval(params[1])
            self.my_env = KeyCollection(rendering=bRender, num_keys=bKeys, size=bSize)
            self.my_env.reset()
            obs = self.my_env.get_state()
            self.my_env.observation_space = Box(low=-np.inf, high=np.inf, shape=obs.shape, dtype=np.float32)
            self.my_env.action_space = Discrete(4)
            print("KeyCollection ", self.my_env.scr_w, "x", self.my_env.scr_h, " created with ", self.my_env.num_keys, " keys.")
            if (bRender): self.my_env.render()

        elif(basename == "JackCarRental"):
            from insoco.environments.jackcar import JackCarRentalEnv
            if(params): 
                param = int(name.split('-')[1])
                if(len(params) > 1):
                    trent = literal_eval(params[0])
                    tret = literal_eval(params[1])
                    self.my_env = JackCarRentalEnv(max_cars = param, rents_per_day = trent, returns_per_day = tret)
                else:
                    self.my_env = JackCarRentalEnv(max_cars = param)
            else:
                self.my_env = JackCarRentalEnv()

        elif(basename == "TwoArms"):
            from insoco.environments import box2d_biarms
            self.my_env = box2d_biarms.TwoArmsEnv()

        elif(basename == "DualCart"):
            from insoco.environments import box2d_dualcart
            self.my_env = box2d_dualcart.DualCartSimEnv(multi_agent_mode=self.multi_agent_mode)
            
        elif(basename == "BimanualRobot"):
            from insoco.environments import box2d_bimanualsim
            self.my_env = box2d_bimanualsim.BimanualSimEnv()

        elif(basename == "Wisconsin"):
            from insoco.environments.Wisconsin import Wisconsin
            render = True
            game_len=50

            self.my_env = Wisconsin(rendering=render, gamelen=game_len)
            self.my_env.reset()
            obs = self.my_env.get_state()
            self.my_env.observation_space = Box(low=np.inf, high=np.inf, shape = obs.shape, dtype=np.int)
            self.my_env.action_space= Discrete(4)
            print("Wisconsin Card Test started with ", game_len, " trials.")
            if(render == True): self.my_env.render()

        elif(self.name == "FinalGrid"):
            from insoco.environments.finalgrid import FinalGrid
            conf = self.conf
            self.my_env = FinalGrid(conf=conf)
            obs = self.my_env.reset()
            self.my_env.observation_space = Box(low=np.inf, high=np.inf, shape=obs.shape, dtype=np.float)
            self.my_env.action_space = Discrete(self.my_env.nactions)
            self.my_env.agent_num = 1 if "num_agents" not in conf else conf["num_agents"]

        elif(self.name == "Continuous1D"):
            from insoco.environments.continuous1D import Continuous1D
            self.my_env = Continuous1D()
            self.my_env.observation_space = Box(low=np.inf, high=np.inf, shape=(1,), dtype=np.float)
            self.my_env.action_space = Box(low=-0.1, high=0.1, shape=(1,), dtype=np.float)

        else:
            print("No environment found")
            return

        self.action_space = self.my_env.action_space
        self.observation_space = self.my_env.observation_space

        if isinstance(self.my_env.action_space,Box):
            low = self.my_env.action_space.low
            high = self.my_env.action_space.high
            print("Continuous Action Space:", self.my_env.action_space, "Low", low, "High", high)
            if self.discretize_action > 0:
                self.action_space = Discrete(self.discretize_action)
                for i in range(len(low)):
                    self.action_values = np.linspace(low[i], high[i], num=self.discretize_action)
                print("Discretizing actions to",self.action_values)

        else:
            print("Discrete Action Space with", self.my_env.action_space)            

        if isinstance(self.my_env,discrete.DiscreteEnv):
            self.nS = self.my_env.nS
            self.nA = self.my_env.nA
            self.nactions = self.nA
            self.P = self.my_env.P
            self.shape = self.my_env.shape

        if hasattr(self,"my_env"):
            if hasattr(self.my_env,"nactions"):
                self.nactions = self.my_env.nactions
            if hasattr(self.my_env,"num_agents"):
                self.num_agents = self.my_env.num_agents

        self.i_episode = -1
        self.reset()

    def seed(self):
        try:
            self.my_env.seed()
        except:
            pass

    def reset(self):
        self.t = 0
        self.i_episode += 1
        conf = self.conf
        if conf is not None:
            if "stats" in conf:
                self.stats = conf["stats"]
                stats = self.stats
            if "run" in conf and "stats" in conf["run"]:
                self.stats = conf["run"]["stats"]
                stats = self.stats

            if hasattr(self,"stats"): 
                if not "reward_sum" in stats:
                    stats["step_sum"] = 0
                    stats["reward_sum"] = 0 if self.num_agents == 1 else np.array([0.0]*self.num_agents)
                    stats["action_sum"] = np.array([0.0]*self.nactions)

                stats["episode_reward"] = 0 if self.num_agents == 1 else np.array([0.0]*self.num_agents)
                stats["episode_action"] = np.array([0.0]*self.nactions)

                self.stats_freq = 1
                if "run" in conf:
                    n_epi = self.conf["run"]["num_episodes"] / 10                
                    self.stats_freq = stats["stats_freq"] if "stats_freq" in stats else n_epi

                self.my_env.stats = self.stats   # stats_freq is freq update in nº episodes / every freq the mean is added to a list                 
                if hasattr(self.my_env,"stats_ini"):
                    self.my_env.stats_ini()


        state = self.my_env.reset()
        if(self.basename in ["TwoArms", "FruitCollection","KeyCollection"]):
            state = self.my_env.get_state()        
        return state

    def stats_update(self, s, a, r, done):
        if not hasattr(self,"stats"): return
        stats = self.stats
        stats["episode_reward"] += r            # put to 0 every reset
        for i in a:                  
            stats["episode_action"][i] += 1     # put to 0 every reset
        
        if hasattr(self.my_env,"stats_update"):
            self.my_env.stats_update()
        
        if done:
            stats["reward_sum"] += np.array(stats["episode_reward"])
            stats["action_sum"] += stats["episode_action"]
            stats["step_sum"] += self.t

            if "i_episode" in stats:
                i_episode = stats["i_episode"]
            else:
                i_episode = self.i_episode

            if (i_episode + 1) % self.stats_freq == 0:   # number of episodes for updating
                for t in ["reward", "action", "step"]: # we update all stats
                    freq_str, sum_str = "freq_"+t+"_list", t+"_sum"
                    if freq_str in stats:
                        stats[freq_str] += [stats[sum_str] / self.stats_freq]
                stats["step_sum"] = 0
                stats["reward_sum"] = 0 if self.num_agents == 1 else np.array([0.0]*self.num_agents)
                stats["action_sum"] = np.array([0.0]*self.nactions)

    
    def steps(self, actions):
        state, reward, done, info = self.my_env.steps(actions)
        done = done or self.t == self.max_steps
        self.stats_update(state, actions, reward, done)
        self.t += 1
        return state, reward, done, info


    def step(self, action):
        state, reward, done, info = self.my_env.step(action)
        done = done or self.t == self.max_steps
        self.stats_update(state, [action], reward, done)
        self.t += 1
        return state, reward, done, info


    def index2state(self,index):
        return np.unravel_index(index, self.my_env.shape)

    def state2index(self,state):
        return np.ravel_multi_index(state, self.my_env.shape)

    def set_figure(self, figure):
        self.fig = figure

    def render(self, param=None):
        if(param is not None):
            return self.my_env.render(param=param)
        else:
            if(self.fig is not None):
                return self.my_env.render(param=self.fig)
            else:
                return self.my_env.render()

    def close(self):
        self.my_env.close()


    def getGridSize(self):
        if(self.basename in ["FruitCollection"]):
            return (self.my_env.scr_w, self.my_env.scr_h)
        return None

    def getAgentPos(self):
        if(self.basename in ["FruitCollection"]):
            return (self.my_env.player_pos_x, self.my_env.player_pos_y)
        return None

    def get_env(self):
        return self.my_env
        
